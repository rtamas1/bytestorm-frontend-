<?php
// agromi-proxy.php (scraping-only, robust + debug)
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Access-Control-Allow-Origin: *');

function outJson($d, $c = 200)
{
    http_response_code($c);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

function http_get($url)
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT =>
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36',
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer: https://google.com/'
            ],
        ]);
        $resp = curl_exec($ch);
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE) ?: 0;
        $err  = curl_error($ch) ?: null;
        curl_close($ch);
        return [$http, $resp, $err];
    }
    $ctx = stream_context_create(['http' => [
        'method' => 'GET',
        'timeout' => 15,
        'header' => "User-Agent: Mozilla/5.0\r\nReferer: https://google.com/\r\n"
    ]]);
    $resp = @file_get_contents($url, false, $ctx);
    $http = 0;
    global $http_response_header;
    if (isset($http_response_header[0]) && preg_match('#\s(\d{3})#', $http_response_header[0], $m)) $http = (int)$m[1];
    return [$http, $resp, $resp === false ? 'stream failed' : null];
}

// ---------- Scraper flexibil pentru liste Woo ----------
// --- helper: extrage produse dintr-o listă (fără product-category)
function parse_products_from_dom(DOMXPath $xp, DOMNode $context, int $limit, array &$collected): void
{
    $nodes = $xp->query(
        ".//li[contains(concat(' ',normalize-space(@class),' '),' product ')
               and not(contains(concat(' ',normalize-space(@class),' '),' product-category '))] |
         .//div[contains(concat(' ',normalize-space(@class),' '),' product ')
               and not(contains(concat(' ',normalize-space(@class),' '),' product-category '))]",
        $context
    );

    if (!$nodes) return;

    foreach ($nodes as $n) {
        if (count($collected) >= $limit) break;

        $a   = $xp->query(".//a[contains(@class,'woocommerce-LoopProduct-link') or contains(@class,'product-link') or self::a]", $n)->item(0);
        $t   = $xp->query(".//*[contains(@class,'woocommerce-loop-product__title') or contains(@class,'product-title') or self::h2 or self::h3]", $n)->item(0);
        $p   = $xp->query(".//*[contains(@class,'price') or contains(@class,'amount')]", $n)->item(0);
        $img = $xp->query(".//img", $n)->item(0);

        // imagine: ia src / data-src / srcset și normalizează (-WxH, -scaled)
        $src = null;
        if ($img instanceof DOMElement) {
            $src = $img->getAttribute('data-src')
                ?: $img->getAttribute('data-lazy-src')
                ?: $img->getAttribute('src');

            if (!$src) {
                $ss = $img->getAttribute('data-srcset') ?: $img->getAttribute('srcset');
                if ($ss) {
                    $first = preg_split('/\s*,\s*/', $ss)[0] ?? '';
                    // „url 275w” -> „url”
                    $src = trim(preg_replace('/\s+\d+w$/', '', $first));
                }
            }

            if ($src) {
                // elimină sufixul -<lat>x<înalț> și -scaled înainte de extensie
                $src = preg_replace('/-\d+x\d+(?=\.(?:jpg|jpeg|png|webp))(?:\?.*)?$/i', '', $src);
                $src = preg_replace('/-scaled(?=\.(?:jpg|jpeg|png|webp))(?:\?.*)?$/i', '', $src);
            }
        }

        // titlu curățat
        $name = $t ? trim(preg_replace('/\s+/', ' ', $t->textContent)) : 'Produs';

        // preț (lasă HTML-ul la nivel de text curățat; îl vei formata în frontend)
        $price = $p ? trim(preg_replace('/\s+/', ' ', $p->textContent)) : '';

        // permalink
        $href = ($a instanceof DOMElement) ? $a->getAttribute('href') : null;

        $collected[] = [
            'name'      => $name,
            'permalink' => $href,
            'image'     => $src,
            'price'     => $price,
        ];
    }
}


// --- helper: extrage link-urile de subcategorii (pentru fallback)
function parse_subcategory_links(DOMXPath $xp, DOMNode $context, $max = 3)
{
    $cats = [];
    $nodes = $xp->query(".//li[contains(@class,'product-category')] | .//div[contains(@class,'product-category')]", $context);
    foreach ($nodes as $n) {
        if (count($cats) >= $max) break;
        $a = $xp->query(".//a[@href]", $n)->item(0);
        if ($a instanceof DOMElement) {
            $cats[] = $a->getAttribute('href');
        }
    }
    return $cats;
}

// --- noua scrape_wc_list: ia produse; dacă nu sunt, urmărește câteva subcategorii
function scrape_wc_list($url, $limit = 8, $debug = false)
{
    [$http, $html, $err] = http_get($url);
    $meta = ['url' => $url, 'http' => $http, 'err' => $err, 'len' => $html ? strlen($html) : 0];
    if ($http < 200 || $http >= 300 || !$html) return $debug ? ['_meta' => $meta, 'items' => []] : [];

    $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML($html);
    $xp  = new DOMXPath($dom);

    $items = [];
    // 1) încearcă să extragi produse direct
    parse_products_from_dom($xp, $dom, $limit, $items);

    // 2) dacă nu s-au găsit, urmează câteva subcategorii și adună de acolo
    if (count($items) < $limit) {
        $cats = parse_subcategory_links($xp, $dom, 4); // urmărește max 4 categorii
        foreach ($cats as $catUrl) {
            if (count($items) >= $limit) break;
            [$h2, $html2, $err2] = http_get($catUrl);
            if ($h2 >= 200 && $h2 < 300 && $html2) {
                $html2 = mb_convert_encoding($html2, 'HTML-ENTITIES', 'UTF-8');
                $dom2 = new DOMDocument();
                $dom2->loadHTML($html2);
                $xp2  = new DOMXPath($dom2);
                parse_products_from_dom($xp2, $dom2, $limit, $items);
            }
        }
        $meta['followed_cats'] = $cats;
    }

    if ($debug) {
        $meta['collected'] = count($items);
        return ['_meta' => $meta, 'items' => $items];
    }
    return $items;
}


/* ==== mapări categorii (verificate) ==== */
$CATS = [
    // ——— Produse utilitare
    'ingrasaminte' => 'https://agromi.ro/categorie-produs/ingrasaminte/',
    'fertilizatori' => 'https://agromi.ro/categorie-produs/ingrasaminte/',
    'fertilizanti'  => 'https://agromi.ro/categorie-produs/ingrasaminte/',

    'pesticide'     => 'https://agromi.ro/categorie-produs/pesticide/',

    'recipiente'    => 'https://agromi.ro/categorie-produs/tavi-alveolare-si-ghivece/',
    'tavi-rasad'    => 'https://agromi.ro/categorie-produs/tavi-alveolare-si-ghivece/',
    'ghivece'       => 'https://agromi.ro/categorie-produs/tavi-alveolare-si-ghivece/',

    'irigatii'      => 'https://agromi.ro/categorie-produs/sisteme-de-irigatie/',
    'irigare'       => 'https://agromi.ro/categorie-produs/sisteme-de-irigatie/',

    // ——— Semințe profesionale
    'tomate'        => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/tomate/',
    'rosii'         => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/tomate/',
    'rosii-hibrid'  => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/tomate/',

    'castraveti'            => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/castraveti/',
    'seminte-castraveti'    => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/castraveti/',

    'salata'        => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/salata/',
    'seminte-salata' => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/salata/',
    'laptuca'       => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/salata/',

    // ——— Altele (exemplu existent)
    'ardei'         => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/ardei/',
    'spanac'        => 'https://agromi.ro/categorie-produs/seminte-de-legume/seminte-profesionale/spanac/',

    // ——— Fallback general
    'seminte-all'   => 'https://agromi.ro/categorie-produs/seminte-de-legume/',
];


$route = $_GET['route'] ?? 'scrape';
$cat   = $_GET['cat']   ?? 'ingrasaminte';
$per   = max(1, min(40, (int)($_GET['per_page'] ?? 8)));
$debug = isset($_GET['debug']);
if ($route === 'ping') {
    outJson(['ok' => true, 'at' => date('c')]);
}
if ($route === 'scrape') {
    if (!isset($CATS[$cat])) outJson(['error' => 'unknown category'], 400);
    $res = scrape_wc_list($CATS[$cat], $per, $debug);
    outJson($res);
}

outJson(['error' => 'route not allowed'], 400);
