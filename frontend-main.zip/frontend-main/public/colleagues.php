<?php
// /api/colleagues.php – proxy HTTPS -> HTTP pentru API-ul colegilor
// Exemplu:
//   GET  /api/colleagues.php?path=sensors&identifier=...  -> http://84.247.140.193:5050/api/sensors?identifier=...
//   GET  /api/colleagues.php?path=reports&identifier=...  -> http://84.247.140.193:5050/api/reports?identifier=...
//   POST /api/colleagues.php?path=command&identifier=...  -> http://84.247.140.193:5050/api/command?identifier=...

error_reporting(E_ALL);
ini_set('display_errors', 0);

// răspuns default JSON
header('Content-Type: application/json; charset=utf-8');

$STATIC_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6InRlc3RAZ3JlZW5ob3VzZS5vcmciLCJyb2xlIjoxLCJpYXQiOjE3NTY5NjEyNjEsImV4cCI6MTc1NzA0NzY2MX0.VwLf7TRQC3UfhNc0U23IqS6BZZOtOvaz3zdcViQJzyo';
$BASE = 'http://84.247.140.193:5050/api';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path   = isset($_GET['path']) ? trim($_GET['path'], "/") : '';

$allowed = [
    'sensors' => ['GET'],
    'reports' => ['GET'],
    'command' => ['POST'], // <- adăugat
];

if (!isset($allowed[$path]) || !in_array($method, $allowed[$path], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'bad_path_or_method', 'path' => $path, 'method' => $method]);
    exit;
}

// construiește URL-ul upstream
$params = $_GET;
unset($params['path']);
$qs  = http_build_query($params);
$url = $BASE . '/' . $path . ($qs ? ('?' . $qs) : '');

// preia header-ele de la client (preferă Authorization din request; altfel folosește tokenul static)
$inHeaders = function_exists('getallheaders') ? getallheaders() : [];
$auth = $inHeaders['Authorization'] ?? ($STATIC_TOKEN ? "Bearer {$STATIC_TOKEN}" : null);
$ctypeIn = $inHeaders['Content-Type'] ?? null;

$ch = curl_init($url);
$headers = array_filter([
    'Accept: application/json, */*;q=0.1',
    $auth ? "Authorization: {$auth}" : null,
]);

// dacă e command -> forward body-ul
if ($path === 'command') {
    // citește corpul brut
    $raw = file_get_contents('php://input');

    // dacă nu e nimic în raw, încearcă din $_POST
    if (($raw === '' || $raw === false) && !empty($_POST)) {
        // dacă Content-Type-ul e form, trimite tot form; altfel JSON
        if ($ctypeIn && stripos($ctypeIn, 'application/x-www-form-urlencoded') !== false) {
            $raw = http_build_query($_POST);
        } else {
            $raw = json_encode($_POST, JSON_UNESCAPED_UNICODE);
            $ctypeIn = 'application/json';
        }
    }

    // dacă tot nu avem Content-Type, presupune JSON
    if (!$ctypeIn) $ctypeIn = 'application/json';

    $headers[] = 'Content-Type: ' . $ctypeIn;
    $headers[] = 'Content-Length: ' . strlen($raw ?? '');

    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS    => $raw ?: '', // poate fi JSON sau form-urlencoded
    ]);
}

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT        => 20,
    CURLOPT_HTTPHEADER     => $headers,
]);

$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE) ?: 0;
$upCtype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?: 'application/json';
$err  = curl_error($ch);
curl_close($ch);

if ($resp === false) {
    http_response_code(502);
    echo json_encode(['error' => 'proxy_failed', 'detail' => $err]);
    exit;
}

// propagă status + content-type de la upstream
if ($upCtype) header('Content-Type: ' . $upCtype);
http_response_code($http);
echo $resp;
