// src/App.jsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Menu from "./components/menu.jsx";
import Home from "./components/MainContent.jsx";
import Statistici from "./pages/Statistici.jsx";
import Harta from "./pages/Harta.jsx";
import Agromi from "./pages/Agromi.jsx";
import Setari from "./pages/Setari.jsx";

export default function App() {
  return (
    <>
      <Menu />
      <main>
        <Routes>
          {/* 1. Acasă / Dashboard */}
          <Route path="/" element={<Home />} />

          {/* 2. Statistici / Automatizări */}
          <Route path="/statistici" element={<Statistici />} />

          {/* 3. Harta Serelor */}
          <Route path="/harta-serelor" element={<Harta />} />

          {/* 4. Agromi */}
          <Route path="/agromi" element={<Agromi />} />

          {/* 5. Setări */}
          <Route path="/settings" element={<Setari />} />

          {/* Fallback către Acasă */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
