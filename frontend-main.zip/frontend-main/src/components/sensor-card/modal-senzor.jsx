import React, { useState, useMemo, useEffect } from "react";
import { Modal, Button, ButtonGroup, Spinner, Alert } from "react-bootstrap";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

const INTERVALS = [
  { key: "24h", label: "24h" },
  { key: "3d", label: "3 zile" },
  { key: "7d", label: "7 zile" },
  { key: "30d", label: "30 zile" },
  { key: "all", label: "Tot" },
];

// === ENV colegi ===
const IS_DEV = import.meta.env.DEV;
const RAW_BASE = (import.meta.env.VITE_COLLEAGUE_API_BASE || "http://84.247.140.193:5050").replace(/\/$/, "");
const PROD_BASE = `${RAW_BASE}/api`;
const TOKEN = import.meta.env.VITE_COLLEAGUE_API_TOKEN || "";
const FALLBACK_BOARD_ID = import.meta.env.VITE_BOARD_ID || "e663ac91d3824a2c";

// map UI -> coloane DB
const ALIAS_TO_DB = {
  temp: "TEMPAER",
  humi_air: "UMDTAER",
  humi_soil1: "UMDTSOL1",
  humi_soil2: "UMDTSOL2",
  humi_soil3: "UMDTSOL3",
  humi_soil4: "UMDTSOL4",
  light: "ILUMINARE",
  water_level: "NIVELAPA",
  air_quality: "CALITAER",
};
const FIELD_WHITELIST = new Set(Object.values(ALIAS_TO_DB));

function hoursForRange(key) {
  switch (key) {
    case "24h":
      return 24;
    case "3d":
      return 72;
    case "7d":
      return 168;
    case "30d":
      return 720;
    case "all":
      return 24 * 90; // 90 zile
    default:
      return 24;
  }
}
function formatHourLabel(date, range) {
  if (range === "24h" || range === "3d") {
    return date.toLocaleTimeString("ro-RO", { hour: "2-digit", minute: "2-digit" });
  }
  return date.toLocaleString("ro-RO", { day: "2-digit", month: "short", hour: "2-digit" });
}
function buildReportsUrl(identifier) {
  if (import.meta.env.DEV) {
    const u = new URL("/ext/reports", window.location.origin);
    u.searchParams.set("identifier", identifier);
    return u.toString();
  } else {
    // PROD: proxy HTTPS pe domeniul tău
    const u = new URL("/colleagues.php", window.location.origin);
    u.searchParams.set("path", "reports");
    u.searchParams.set("identifier", identifier);
    return u.toString();
  }
}

export default function ModalSenzor({ senzor, onClose, boardId: propBoardId }) {
  const [interval, setInterval] = useState("24h");
  const [series, setSeries] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);
  if (!senzor) return null;

  const boardId = propBoardId || FALLBACK_BOARD_ID;
  const fieldDb = ALIAS_TO_DB[senzor.key] || (FIELD_WHITELIST.has(senzor.key) ? senzor.key : null);

  const strokeColor = senzor.status === "healthy" ? "#198754" : senzor.status === "warning" ? "#ffc107" : "#dc3545";

  const historyRange = useMemo(() => (interval === "all" ? "all" : interval), [interval]);

  useEffect(() => {
    let alive = true;

    async function run() {
      if (!fieldDb) {
        setSeries(null);
        setLoading(false);
        setErr("Acest senzor nu are serie numerică în DB.");
        return;
      }
      if (!boardId) {
        setSeries(null);
        setLoading(false);
        setErr("Lipsește boardId.");
        return;
      }

      setLoading(true);
      setErr(null);

      try {
        // 1) Fetch de la colegi
        const url = buildReportsUrl(boardId);
        const headers = { Accept: "application/json" };
        if (!IS_DEV && TOKEN) headers.Authorization = `Bearer ${TOKEN}`;

        const res = await fetch(url, { headers, cache: "no-store" });
        const text = await res.text();
        if (!res.ok) {
          const hint = res.status === 401 ? " (verifică VITE_COLLEAGUE_API_TOKEN; posibil expirat)" : "";
          throw new Error(`HTTP ${res.status}: ${text.slice(0, 200)}${hint}`);
        }

        let payload;
        try {
          payload = JSON.parse(text);
        } catch {
          throw new Error(`Răspuns non-JSON: ${text.slice(0, 200)}`);
        }

        // 2) Suportăm forma „object-of-arrays” (ex. payload.TEMPAER = [{value,timestamp}])…
        //    …dar și fallback pentru alte forme cunoscute.
        const dict = (payload && !Array.isArray(payload) && (payload.data || payload.rows || payload.reports || payload)) || null;

        let rawSeries = [];
        if (dict && dict[fieldDb] && Array.isArray(dict[fieldDb])) {
          rawSeries = dict[fieldDb]; // [{ value, timestamp }, …]
        } else if (Array.isArray(payload)) {
          // fallback: dacă e array de rânduri cu toate coloanele pe fiecare rând
          rawSeries = payload
            .map((r) => ({ value: r[fieldDb], timestamp: r.STIMEACQ || r.timestamp || r.time || r.date }))
            .filter((p) => p.timestamp && (p.value || p.value === 0));
        } else if (Array.isArray(payload?.data)) {
          rawSeries = payload.data
            .map((r) => ({ value: r[fieldDb], timestamp: r.STIMEACQ || r.timestamp || r.time || r.date }))
            .filter((p) => p.timestamp && (p.value || p.value === 0));
        }

        // 3) Normalizare + filtrare pe interval
        const now = Date.now();
        const fromMs = now - hoursForRange(historyRange) * 3600 * 1000;

        const pts = rawSeries
          .map((p) => {
            const ms = Date.parse(String(p.timestamp).replace(" ", "T"));
            const v = Number(p.value);
            return { ms, v };
          })
          .filter((p) => Number.isFinite(p.ms) && Number.isFinite(p.v))
          .sort((a, b) => a.ms - b.ms)
          .filter((p) => (historyRange === "all" ? true : p.ms >= fromMs && p.ms <= now));

        const data = pts.map((p) => ({
          label: formatHourLabel(new Date(p.ms), historyRange),
          value: p.v,
        }));

        if (!alive) return;
        setSeries(data);
      } catch (e) {
        if (!alive) return;
        console.error("[modal] eroare:", e?.message);
        setErr(e?.message || "Nu s-au putut încărca datele de la colegi.");
        setSeries([]);
      } finally {
        if (alive) setLoading(false);
      }
    }

    run();
    return () => {
      alive = false;
    };
  }, [boardId, fieldDb, historyRange]);

  return (
    <Modal show onHide={onClose} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>{senzor.label || senzor.key}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <span style={{ fontSize: "2.5rem", fontWeight: 600, color: strokeColor }}>{senzor.value ?? "—"}</span>
          <div style={{ color: "#666", marginTop: 4 }}>{senzor.helper}</div>
        </div>

        <ButtonGroup className="mb-3">
          {INTERVALS.map((opt) => (
            <Button key={opt.key} variant={interval === opt.key ? "primary" : "outline-secondary"} onClick={() => setInterval(opt.key)}>
              {opt.label}
            </Button>
          ))}
        </ButtonGroup>

        {loading && (
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <Spinner size="sm" /> Se încarcă seria…
          </div>
        )}
        {err && <Alert variant="danger">Eroare: {err}</Alert>}

        {!loading && !err && series && series.length > 0 && (
          <div style={{ width: "100%", height: 300 }}>
            <ResponsiveContainer>
              <LineChart data={series} margin={{ left: -20, right: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" minTickGap={24} />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="value" dot={false} stroke="#0d6efd" isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        {!loading && !err && (!series || series.length === 0) && <div style={{ color: "#555" }}>Nu există date pentru intervalul selectat.</div>}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Închide
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
