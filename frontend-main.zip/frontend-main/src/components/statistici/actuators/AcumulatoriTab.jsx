// src/components/actuators/AcumulatoriTab.jsx
import { useEffect, useMemo, useRef, useState } from "react";
import { buildColleagueUrl, authHeaders } from "../../../lib/colleagueApi";

/* ========= Config (se pot suprascrie prin props) ========= */
const REFRESH_MS_DEFAULT = Math.max(2000, Number(import.meta.env.VITE_REFRESH_MS || 10000));
const ACT_ENDPOINT_DEFAULT = import.meta.env.VITE_ACT_ENDPOINT || "/command";

/* ========= Helpers ========= */
const to01 = (v) => {
  if (v === null || v === undefined) return 0;
  if (typeof v === "number") return v > 0 ? 1 : 0;
  if (typeof v === "boolean") return v ? 1 : 0;
  const s = String(v).trim().toLowerCase();
  if (["1", "on", "true", "open", "high"].includes(s)) return 1;
  if (["0", "off", "false", "closed", "low"].includes(s)) return 0;
  const n = Number(v);
  return Number.isFinite(n) ? (n > 0 ? 1 : 0) : 0;
};
const onOffText = (v) => (to01(v) ? "Pornit" : "Oprit");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const extractStamp = (snap) => snap?.ATIMEACQ || snap?.STIMEACQ || snap?.TTIMEACQ || null;
const stampAgeSec = (stamp) => {
  if (!stamp) return Infinity;
  const t = Date.parse(stamp);
  return Number.isFinite(t) ? Math.max(0, (Date.now() - t) / 1000) : Infinity;
};

function pickField(obj, names) {
  const places = [obj, obj?.state, obj?.status, obj?.outputs, obj?.actuators, obj?.data];
  for (const p of places) {
    if (!p || typeof p !== "object") continue;
    for (const name of names) if (name in p) return p[name];
  }
  return undefined;
}

async function fetchJSON(url, init) {
  const res = await fetch(url, {
    cache: "no-store",
    ...init,
    headers: {
      Accept: init?.method === "POST" ? "*/*" : "application/json",
      ...(init?.headers || {}),
    },
  });
  const text = await res.text();
  const ctype = res.headers.get("content-type") || "";
  if (!res.ok) {
    const base = `HTTP ${res.status}: ${text.slice(0, 240)}`;
    if (res.status === 401) throw new Error("401 – Token expirat/nevalid. Verifică COLLEAGUE_API_TOKEN și repornește dev serverul.");
    if (res.status === 404) throw new Error("404 – Endpoint inexistent. Verifică VITE_ACT_ENDPOINT (ex. /command) și proxy-ul /ext.");
    throw new Error(base);
  }
  if (/application\/json/i.test(ctype)) return JSON.parse(text);
  return { ok: true, text };
}

/* ========= Componenta ========= */
export default function AcumulatoriTab({
  boardId = import.meta.env.VITE_BOARD_ID || "e663ac91d3824a2c",
  refreshMs = REFRESH_MS_DEFAULT,
  actEndpoint = ACT_ENDPOINT_DEFAULT,
  actuators = [
    { key: "TESTLED", label: "LED", primary: "led", icon: "💡" },
    { key: "TESTFAN", label: "Ventilator", primary: "fan", icon: "🌀" },
    { key: "TESTSRV", label: "Servo", primary: "srv", icon: "⚙️" },
    { key: "TESTPMP", label: "Pompă", primary: "pmp", icon: "🌊" },
  ],
  readAliases = {
    TESTLED: ["TESTLED", "led", "LED", "testled", "act_led"],
    TESTFAN: ["TESTFAN", "fan", "FAN", "testfan", "act_fan"],
    TESTSRV: ["TESTSRV", "srv", "servo", "SRV", "SERVO", "testsrv", "act_srv", "act_servo"],
    TESTPMP: ["TESTPMP", "pmp", "pump", "PMP", "PUMP", "testpmp", "act_pmp", "act_pump"],
  },
}) {
  const [snap, setSnap] = useState(null);
  const [error, setError] = useState(null);
  const [busyKey, setBusyKey] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const aliveRef = useRef(true);
  const timerRef = useRef(null);
  const locksRef = useRef({}); // optimistic UI pentru confirmare la următorul snapshot/raport

  /* ===== API locale ===== */
  const getSnapshot = async () => {
    const url = buildColleagueUrl("/sensors", { identifier: boardId, _: Date.now() });
    const j = await fetchJSON(url, { headers: authHeaders() });
    return j?.data ?? j;
  };

  const getReports = async () => {
    const url = buildColleagueUrl("/reports", { identifier: boardId, _: Date.now() });
    try {
      const j = await fetchJSON(url, { headers: authHeaders() });
      const list = Array.isArray(j) ? j : Array.isArray(j?.data) ? j.data : [];
      return list;
    } catch {
      return [];
    }
  };

  const reportsConfirmAction = (reports, key, want, sinceMs) => {
    const aliases = readAliases[key] || [key];
    const wantStr = want ? "on" : "off";
    const wantNum = want ? 1 : 0;
    for (const r of reports) {
      const t = Date.parse(r.timestamp || r.time || r.created_at || r.date || "");
      if (sinceMs && Number.isFinite(t) && t < sinceMs) continue;
      const act = (r.actuator || r.action || r.key || r.name || "").toString().toLowerCase();
      const val = r.value ?? r.state ?? r.new_value ?? r.payload?.value ?? r.data?.value;
      if (!act) continue;
      const matchAct = (aliases || []).some((a) => act.includes(String(a).toLowerCase()));
      if (!matchAct) continue;
      const v01 = to01(val);
      if (v01 === wantNum) return true;
      if (String(val).toLowerCase() === wantStr) return true;
    }
    return false;
  };

  const postCommand = async (actuator, value) => {
    const payload = { deviceId: boardId, actuator, value };
    const url = buildColleagueUrl("/command", { identifier: boardId });
    const res = await fetch(url, {
      method: "POST",
      headers: { ...authHeaders(), "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      cache: "no-store",
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${text}`);
    return true;
  };

  const waitForConfirmation = async (key, want, cmdAtMs, maxMs = 90000) => {
    const t0 = Date.now();
    let lastSnap = null;
    while (Date.now() - t0 < maxMs) {
      const s = await getSnapshot();
      lastSnap = s;
      const nowVal = to01(pickField(s, readAliases[key] || [key]));
      const stmp = extractStamp(s);
      if (nowVal === want && (!stmp || Date.parse(stmp) >= cmdAtMs)) {
        return { confirmed: true, via: "sensors", snap: s, stamp: stmp };
      }
      const reports = await getReports();
      if (reportsConfirmAction(reports, key, want, cmdAtMs)) {
        return { confirmed: true, via: "reports", snap: s, stamp: stmp };
      }
      await sleep(800);
    }
    return { confirmed: false, via: "timeout", snap: lastSnap, stamp: extractStamp(lastSnap) };
  };

  /* ===== lifecycle ===== */
  const load = async (fromBtn = false) => {
    try {
      if (fromBtn) setIsRefreshing(true);
      const s = await getSnapshot();
      if (!aliveRef.current) return;

      // curățăm lock-urile expirate
      const stmp = extractStamp(s);
      const st = Number.isFinite(Date.parse(stmp)) ? Date.parse(stmp) : 0;
      const locks = locksRef.current;
      if (st) {
        for (const [k, lk] of Object.entries(locks)) {
          if (!lk) continue;
          if (Date.now() > lk.untilMs) delete locks[k];
        }
      }

      setSnap(s);
      setError(null);
    } catch (e) {
      if (aliveRef.current) setError(String(e?.message || e));
    } finally {
      if (fromBtn) setIsRefreshing(false);
    }
  };

  useEffect(() => {
    aliveRef.current = true;
    load();
    timerRef.current = setInterval(load, refreshMs);
    return () => {
      aliveRef.current = false;
      clearInterval(timerRef.current);
    };
  }, [boardId, refreshMs]);

  const states = useMemo(() => {
    const map = {};
    const stmp = extractStamp(snap);
    const st = Number.isFinite(Date.parse(stmp)) ? Date.parse(stmp) : 0;
    const locks = locksRef.current;
    for (const a of actuators) {
      let raw = snap?.[a.key];
      if (raw === undefined) raw = pickField(snap, readAliases[a.key] || [a.key]);
      let val = to01(raw);
      const lk = locks[a.key];
      if (lk) {
        if (!st || st < lk.cmdAtMs) val = lk.want; // optimistic până vine snapshot
        if (lk.confirmedVia === "reports") val = lk.want;
      }
      map[a.key] = val;
    }
    return map;
  }, [snap, actuators, readAliases]);

  async function send(key, wantOn) {
    const act = actuators.find((x) => x.key === key);
    if (!act) return;
    setBusyKey(key);
    setError(null);

    const cmdAtMs = Date.now();
    locksRef.current[key] = { want: wantOn ? 1 : 0, cmdAtMs, untilMs: cmdAtMs + 90000 };

    try {
      await postCommand(act.primary, wantOn ? "on" : "off");
    } catch (e) {
      delete locksRef.current[key];
      const msg = String(e?.message || e);
      let hint = "";
      if (msg.startsWith("401")) hint = " Verifică COLLEAGUE_API_TOKEN în .env.";
      else if (msg.startsWith("404")) hint = " Verifică VITE_ACT_ENDPOINT (ex. /command) și proxy-ul /ext.";
      else if (msg.includes("Failed to fetch")) hint = " Conexiune/policy CORS.";
      setError(`${msg}${hint}`);
      setBusyKey(null);
      return;
    } finally {
      setBusyKey(null);
    }

    // Confirmare „silencioasă” – UI rămâne optimist, fără mesaje de debug
    try {
      const want = wantOn ? 1 : 0;
      const { confirmed, via, snap: finalSnap } = await waitForConfirmation(key, want, cmdAtMs, 90000);
      if (confirmed) {
        if (via === "reports") {
          locksRef.current[key] = {
            ...(locksRef.current[key] || {}),
            want,
            cmdAtMs,
            untilMs: Date.now() + 90000,
            confirmedVia: "reports",
          };
        } else {
          delete locksRef.current[key];
        }
        if (finalSnap) setSnap(finalSnap);
      } else {
        delete locksRef.current[key];
        if (finalSnap) setSnap(finalSnap);
        // nu afișăm mesaj de debug, doar păstrăm UI consistent
      }
    } catch (e) {
      delete locksRef.current[key];
      // fără mesaj suplimentar – păstrăm UI curat
    }
  }

  /* ===== UI ===== */
  const styles = {
    wrap: {},
    errBox: { background: "#ffe6e6", color: "#7a0612", padding: 10, borderRadius: 8, marginBottom: 12 },
    grid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 16 },
    card: { background: "#1f2937", color: "white", borderRadius: 14, padding: 16, boxShadow: "0 6px 18px rgba(0,0,0,.15)" },
    cardHeader: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
    cardTitle: { fontSize: 22, display: "flex", alignItems: "center", gap: 8 },
    badge: (on) => ({ background: on ? "#16a34a" : "#9ca3af", color: "white", padding: "4px 10px", borderRadius: 999, fontSize: 12, letterSpacing: 0.3 }),
    btnRow: { display: "flex", gap: 10 },
    btn: (bg) => ({ flex: 1, padding: "10px 12px", borderRadius: 10, border: "none", cursor: "pointer", background: bg, color: "white", fontWeight: 600 }),
    btnGhost: { padding: "8px 12px", borderRadius: 10, border: "1px solid #e5e7eb", background: "white", cursor: "pointer" },
    refreshRow: { marginTop: 16, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" },
    lastRef: { fontSize: 12, opacity: 0.7 },
    staleWarn: { fontSize: 12, color: "#b45309", background: "#fffbeb", padding: "6px 10px", borderRadius: 8, border: "1px solid #f59e0b" },
  };

  return (
    <div style={styles.wrap}>
      {error && (
        <div style={styles.errBox}>
          <strong>Eroare:</strong> {error}
        </div>
      )}

      <div style={styles.grid}>
        {actuators.map((a) => {
          const on = states[a.key] === 1;
          const isSending = busyKey === a.key;

          return (
            <div key={a.key} style={styles.card}>
              <div style={styles.cardHeader}>
                <div style={styles.cardTitle}>
                  <span style={{ marginRight: 0 }}>{a.icon}</span>
                  {a.label}
                </div>
                <div style={styles.badge(on)}>{onOffText(on)}</div>
              </div>

              <div style={styles.btnRow}>
                <button
                  disabled={isSending || on}
                  onClick={() => send(a.key, true)}
                  style={{ ...styles.btn("#10b981"), opacity: isSending || on ? 0.6 : 1, cursor: isSending || on ? "not-allowed" : "pointer" }}>
                  {isSending ? "…" : "ON"}
                </button>
                <button
                  disabled={isSending || !on}
                  onClick={() => send(a.key, false)}
                  style={{ ...styles.btn("#ef4444"), opacity: isSending || !on ? 0.6 : 1, cursor: isSending || !on ? "not-allowed" : "pointer" }}>
                  {isSending ? "…" : "OFF"}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div style={styles.refreshRow}>
        <button onClick={() => load(true)} style={styles.btnGhost} disabled={isRefreshing}>
          {isRefreshing ? "Se încarcă…" : "Reîmprospătează"}
        </button>
        <div style={styles.lastRef}>
          Ultimul refresh: <code>{extractStamp(snap) || "—"}</code>
        </div>
        {(() => {
          const stamp = extractStamp(snap);
          const staleSec = stampAgeSec(stamp);
          if (!snap || staleSec <= 90) return null;
          return (
            <div style={styles.staleWarn}>
              Atenție: date mai vechi de {Math.round(staleSec)}s (ultimul snapshot: <code>{stamp}</code>).
            </div>
          );
        })()}
      </div>
    </div>
  );
}
