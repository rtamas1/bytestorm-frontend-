// src/components/setari/SectionNotifications.jsx
import React, { useEffect, useMemo, useState } from "react";
import { Card, Row, Col, Form, Collapse } from "react-bootstrap";
import { notificationsStore } from "../../lib/notificationsStore";

const SEED = [
  { id: 1, sera: "Sera Spanac", message: "Temperatura va crește la 30° în următoarele zile.", type: "warning", status: "activ" },
  { id: 2, sera: "Sera Roșii", message: "În 5 zile se anunță precipitații de 2 L/mp.", type: "info", status: "activ" },
  { id: 3, sera: "Sera Castraveți", message: "Umiditatea solului a depășit 80%.", type: "urgent", status: "activ" },
  { id: 4, sera: "Sera Spanac", message: "Recoltarea spanacului se face în 8 zile.", type: "success", status: "activ" },
  { id: 5, sera: "Sera Ardei", message: "Verifică nivelul de nutrienți din rezervor.", type: "info", status: "activ" },
  { id: 6, sera: "Sera Castraveți", message: "Vânt puternic anunțat pentru joi.", type: "warning", status: "activ" },
  { id: 7, sera: "Sera Ardei", message: "Nivelul apei a scăzut sub 30%.", type: "urgent", status: "activ" },
  { id: 8, sera: "Sera Roșii", message: "Program de udare actualizat.", type: "success", status: "activ" },
];

export default function SectionNotifications({ formData, onChange }) {
  const [prefsOpen, setPrefsOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);

  // seed o singură dată dacă nu există date
  useEffect(() => {
    notificationsStore.seedIfEmpty(SEED);
  }, []);

  // ține lista sincronizată cu store-ul
  useEffect(() => {
    const unsubscribe = notificationsStore.subscribe(setNotifications);
    return unsubscribe;
  }, []);

  const activeCount = useMemo(() => notifications.filter((n) => n.status === "activ").length, [notifications]);

  const handleMarkAsDone = (id) => notificationsStore.update(id, { status: "realizat" });
  const handlePostpone = (id) => notificationsStore.update(id, { status: "amanat" });
  const handleCancel = (id) => notificationsStore.remove(id);

  return (
    <>
      {/* CARD — Preferințe */}
      <Card className="settings-card mb-3">
        <Card.Header
          as="button"
          type="button"
          className="prefs-acc-toggle w-100 d-flex align-items-center justify-content-between"
          onClick={() => setPrefsOpen((v) => !v)}
          aria-expanded={prefsOpen}>
          <span>
            <i className="bi bi-sliders me-2" /> Preferințe Notificări
          </span>
          <i className={`bi ${prefsOpen ? "bi-chevron-up" : "bi-chevron-down"}`} />
        </Card.Header>

        <Collapse in={prefsOpen}>
          <div>
            <Card.Body>
              <h6 className="mb-3">Canale de Notificare</h6>
              <Row className="mb-4">
                <Col md={4}>
                  <Form.Check
                    type="switch"
                    id="email-switch"
                    label="Email"
                    name="notificariEmail"
                    checked={!!formData.notificariEmail}
                    onChange={onChange}
                    className="custom-switch"
                  />
                </Col>
                <Col md={4}>
                  <Form.Check type="switch" id="sms-switch" label="SMS" name="notificariSMS" checked={!!formData.notificariSMS} onChange={onChange} className="custom-switch" />
                </Col>
                <Col md={4}>
                  <Form.Check
                    type="switch"
                    id="push-switch"
                    label="Push Notifications"
                    name="notificariPush"
                    checked={!!formData.notificariPush}
                    onChange={onChange}
                    className="custom-switch"
                  />
                </Col>
              </Row>

              <h6 className="mb-3">Tipuri de Alerte</h6>
              <Row>
                <Col md={6}>
                  <Form.Check
                    type="checkbox"
                    id="temp-alert"
                    label="Alerte Temperatură"
                    name="alerteTemperatura"
                    checked={!!formData.alerteTemperatura}
                    onChange={onChange}
                    className="custom-checkbox mb-3"
                  />
                  <Form.Check
                    type="checkbox"
                    id="humidity-alert"
                    label="Alerte Umiditate"
                    name="alerteUmiditate"
                    checked={!!formData.alerteUmiditate}
                    onChange={onChange}
                    className="custom-checkbox mb-3"
                  />
                  <Form.Check
                    type="checkbox"
                    id="wind-alert"
                    label="Alerte Vânt Puternic"
                    name="alerteVent"
                    checked={!!formData.alerteVent}
                    onChange={onChange}
                    className="custom-checkbox"
                  />
                </Col>
                <Col md={6}>
                  <div className="alert-preview">
                    <h6>Preview Notificare:</h6>
                    <div className="preview-box d-flex align-items-start gap-2">
                      <i className="bi bi-exclamation-triangle-fill text-warning" />
                      <div>
                        <strong>Alertă Temperatură</strong>
                        <p className="mb-0 small">Temperatura într-o seră a depășit 35°C</p>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </div>
        </Collapse>
      </Card>

      {/* CARD — grila cu notificări */}
      <Card className="settings-card">
        <Card.Body>
          {activeCount === 0 ? (
            <div className="text-center text-muted py-4">Nu există notificări active în acest moment.</div>
          ) : (
            <div className="notif-grid notif-grid--4">
              {notifications
                .filter((n) => n.status === "activ")
                .map((notif) => (
                  <div key={notif.id} className={`notif-card ${notif.type}`}>
                    <div className="notif-top">
                      <span className="sera-badge">
                        <i className="bi bi-house-door" />
                        {notif.sera}
                      </span>
                    </div>
                    <div className="notif-message">{notif.message}</div>
                    <div className="notif-actions">
                      <button onClick={() => handleMarkAsDone(notif.id)} className="notif-btn btn-ok">
                        Realizat
                      </button>
                      <button onClick={() => handlePostpone(notif.id)} className="notif-btn btn-postpone">
                        Amanat
                      </button>
                      <button onClick={() => handleCancel(notif.id)} className="notif-btn btn-cancel">
                        Anulat
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </Card.Body>
      </Card>
    </>
  );
}
