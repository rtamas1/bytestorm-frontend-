// src/pages/Harta.jsx
import React from "react";
import GreenhouseDesigner from "../components/greenhouse/GreenhouseDesigner";

export default function Harta() {
  return (
    <section className="section gh-page">
      <GreenhouseDesigner />
    </section>
  );
}
