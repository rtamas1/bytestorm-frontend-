export interface SensorData {
    SDATA_ID: number;
    STIMEACQ: string;
    SBOARDID: string;
    TEMPAER: number;      // Air Temperature
    UMDTAER: number;      // Air Humidity
    UMDTSOL1: number;     // Soil Moisture 1
    UMDTSOL2: number;     // Soil Moisture 2
    NIVELAPA: number;     // Water Level
    EXCESAPA: number;     // Excess Water
    ILUMINARE: number;    // Illumination
    CALITAER: number;     // Air Quality
    STAREAER: string;     // Air State
    TEMPINT: number;      // Internal Temperature
    TESTLED: number;      // LED Status
    TESTFAN: number;      // Fan Status
    TESTSRV: number;      // Servo Status
    TESTPMP: number;      // Pump Status
    // Technical data
    TDATA_ID: number;
    TTIMEACQ: string;
    TBOARDID: string;
    UNQHWMAC: string;
    TBOARDIP: string;
    SYSUPTIME: number;
    FREEMEM: number;
}

export interface SensorDisplay {
    id: string;
    name: string;
    value: string;
    icon: string;
    color: string;
    unit?: string;
    status?: 'good' | 'warning' | 'danger' | 'neutral';
}