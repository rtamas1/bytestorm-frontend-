export interface WeatherDay {
    date: string;
    dayName: string;
    temperature: {
        min: number;
        max: number;
        current?: number;
    };
    condition: WeatherCondition;
    precipitation: number;
    humidity: number;
    windSpeed: number;
    uvIndex: number;
    sunrise?: string;
    sunset?: string;
    hourlyForecast?: HourlyForecast[];
}

export interface HourlyForecast {
    time: string;
    temp: number;
    condition: string;
}

export interface Location {
    name: string;
    lat: number;
    lon: number;
    country: string;
    state?: string;
}

export type WeatherCondition =
    | 'sunny'
    | 'rainy'
    | 'cloudy'
    | 'partly-cloudy'
    | 'snowy'
    | 'thunderstorm'
    | 'foggy';