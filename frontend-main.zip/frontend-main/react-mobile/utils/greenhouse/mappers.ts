import { SensorData, SensorDisplay } from '@/types/greenhouse';

export const mapSensorDataToDisplay = (data: SensorData): SensorDisplay[] => {
    const sensors: SensorDisplay[] = [
        // Primary Environmental Sensors (Top Row)
        {
            id: 'air-temp',
            name: 'Air Temp',
            value: `${data.TEMPAER}°C`,
            icon: '🌡️',
            color: getTemperatureColor(data.TEMPAER),
            status: getTemperatureStatus(data.TEMPAER),
        },
        {
            id: 'air-humidity',
            name: 'Air Humidity',
            value: `${data.UMDTAER}%`,
            icon: '💧',
            color: getHumidityColor(data.UMDTAER),
            status: getHumidityStatus(data.UMDTAER),
        },
        {
            id: 'light',
            name: 'Light',
            value: `${Math.round(data.ILUMINARE)} lux`,
            icon: '☀️',
            color: getLightColor(data.ILUMINARE),
            status: getLightStatus(data.ILUMINARE),
        },
        {
            id: 'air-quality',
            name: 'Air Quality',
            value: data.STAREAER,
            icon: '💨',
            color: getAirQualityColor(data.STAREAER),
            status: getAirQualityStatus(data.STAREAER),
        },

        // Soil & Water Sensors (Second Row)
        {
            id: 'soil-1',
            name: 'Soil 1',
            value: `${data.UMDTSOL1}%`,
            icon: '🌱',
            color: getSoilMoistureColor(data.UMDTSOL1),
            status: getSoilMoistureStatus(data.UMDTSOL1),
        },
        {
            id: 'soil-2',
            name: 'Soil 2',
            value: `${data.UMDTSOL2}%`,
            icon: '🌿',
            color: getSoilMoistureColor(data.UMDTSOL2),
            status: getSoilMoistureStatus(data.UMDTSOL2),
        },
        {
            id: 'water-level',
            name: 'Water Level',
            value: `${data.NIVELAPA}%`,
            icon: '💦',
            color: getWaterLevelColor(data.NIVELAPA),
            status: getWaterLevelStatus(data.NIVELAPA),
        },
        {
            id: 'excess-water',
            name: 'Drainage',
            value: data.EXCESAPA > 50 ? 'Alert' : 'OK',
            icon: '🚰',
            color: data.EXCESAPA > 50 ? '#e74c3c' : '#27ae60',
            status: data.EXCESAPA > 50 ? 'warning' : 'good',
        },

        // Device Status (Third Row)
        {
            id: 'fan',
            name: 'Fan',
            value: data.TESTFAN === 1 ? 'ON' : 'OFF',
            icon: '🌀',
            color: data.TESTFAN === 1 ? '#27ae60' : '#95a5a6',
            status: 'neutral',
        },
        {
            id: 'pump',
            name: 'Pump',
            value: data.TESTPMP === 1 ? 'ON' : 'OFF',
            icon: '⛽',
            color: data.TESTPMP === 1 ? '#27ae60' : '#95a5a6',
            status: 'neutral',
        },
        {
            id: 'led',
            name: 'LED',
            value: data.TESTLED === 1 ? 'ON' : 'OFF',
            icon: '💡',
            color: data.TESTLED === 1 ? '#f39c12' : '#95a5a6',
            status: 'neutral',
        },
        {
            id: 'servo',
            name: 'Servo',
            value: data.TESTSRV > 0 ? 'ON' : 'OFF',
            icon: '⚙️',
            color: data.TESTSRV > 0 ? '#3498db' : '#95a5a6',
            status: 'neutral',
        },
    ];

    return sensors;
};

// Helper functions for determining colors and status
const getTemperatureColor = (temp: number): string => {
    if (temp < 15) return '#3498db'; // Too cold
    if (temp > 30) return '#e74c3c'; // Too hot
    return '#27ae60'; // Optimal
};

const getTemperatureStatus = (temp: number): 'good' | 'warning' | 'danger' => {
    if (temp < 10 || temp > 35) return 'danger';
    if (temp < 15 || temp > 30) return 'warning';
    return 'good';
};

const getHumidityColor = (humidity: number): string => {
    if (humidity < 40) return '#e67e22'; // Too dry
    if (humidity > 70) return '#3498db'; // Too humid
    return '#27ae60'; // Optimal
};

const getHumidityStatus = (humidity: number): 'good' | 'warning' | 'danger' => {
    if (humidity < 30 || humidity > 80) return 'danger';
    if (humidity < 40 || humidity > 70) return 'warning';
    return 'good';
};

const getLightColor = (lux: number): string => {
    if (lux < 100) return '#34495e'; // Too dark
    if (lux > 1000) return '#f39c12'; // Very bright
    return '#27ae60'; // Good
};

const getLightStatus = (lux: number): 'good' | 'warning' | 'danger' => {
    if (lux < 50) return 'danger';
    if (lux < 100) return 'warning';
    return 'good';
};

const getAirQualityColor = (quality: string): string => {
    switch (quality.toLowerCase()) {
        case 'good': return '#27ae60';
        case 'moderate': return '#f39c12';
        case 'unhealthy': return '#e67e22';
        case 'dangerous': return '#e74c3c';
        default: return '#95a5a6';
    }
};

const getAirQualityStatus = (quality: string): 'good' | 'warning' | 'danger' => {
    switch (quality.toLowerCase()) {
        case 'good': return 'good';
        case 'moderate': return 'warning';
        case 'unhealthy':
        case 'dangerous': return 'danger';
        default: return 'warning';
    }
};

const getSoilMoistureColor = (moisture: number): string => {
    if (moisture < 30) return '#e67e22'; // Too dry
    if (moisture > 80) return '#3498db'; // Too wet
    return '#27ae60'; // Optimal
};

const getSoilMoistureStatus = (moisture: number): 'good' | 'warning' | 'danger' => {
    if (moisture < 20 || moisture > 90) return 'danger';
    if (moisture < 30 || moisture > 80) return 'warning';
    return 'good';
};

const getWaterLevelColor = (level: number): string => {
    if (level < 20) return '#e74c3c'; // Critical low
    if (level < 40) return '#e67e22'; // Low
    return '#3498db'; // Good
};

const getWaterLevelStatus = (level: number): 'good' | 'warning' | 'danger' => {
    if (level < 20) return 'danger';
    if (level < 40) return 'warning';
    return 'good';
};