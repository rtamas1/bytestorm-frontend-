import { WEATHER_ICONS } from '@/constants/weather';
import { WeatherCondition, WeatherDay } from '@/types/weather';
import { formatDateISO, formatTimeISO } from '@/utils/weather/formatters';

export const mapOMWeatherCode = (code: number): WeatherCondition => {
    if (code === 0) return 'sunny';
    if ([1, 2].includes(code)) return 'partly-cloudy';
    if (code === 3) return 'cloudy';
    if ([45, 48].includes(code)) return 'foggy';
    if ([51, 53, 55, 56, 57].includes(code)) return 'rainy';
    if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return 'rainy';
    if ([71, 73, 75, 77, 85, 86].includes(code)) return 'snowy';
    if ([95, 96, 99].includes(code)) return 'thunderstorm';
    return 'cloudy';
};

export const getOMIcon = (code: number): string => {
    const condition = mapOMWeatherCode(code);
    return WEATHER_ICONS[condition];
};

export const processOpenMeteoData = (data: any): WeatherDay[] => {
    const days: WeatherDay[] = [];

    const daily = data.daily || {};
    const hourly = data.hourly || {};
    const current = data.current || {};

    const dailyCount = (daily.time || []).length;
    const now = current.time ? new Date(current.time) : new Date();

    // Helper to filter hourly indices for a given YYYY-MM-DD
    const hourlyIndicesForDate = (yyyyMMdd: string) => {
        const times: string[] = hourly.time || [];
        const indices: number[] = [];
        for (let i = 0; i < times.length; i++) {
            if (times[i].startsWith(yyyyMMdd)) indices.push(i);
        }
        return indices;
    };

    for (let i = 0; i < dailyCount; i++) {
        const dateISO = daily.time[i]; // "YYYY-MM-DD"
        const { date, dayName } = formatDateISO(dateISO);
        const isToday = i === 0;

        // temps
        const tMax = Math.round(daily.temperature_2m_max?.[i] ?? NaN);
        const tMin = Math.round(daily.temperature_2m_min?.[i] ?? NaN);

        // condition + precip + wind + uv
        const wCode = daily.weather_code?.[i] ?? 3; // default cloudy
        const cond = mapOMWeatherCode(wCode);
        const precipPct = Math.round(daily.precipitation_probability_max?.[i] ?? 0);
        const windMax = Math.round(daily.wind_speed_10m_max?.[i] ?? 0);
        const uvDay = Math.round(daily.uv_index_max?.[i] ?? 5);

        // sunrise/sunset
        const sunriseISO = daily.sunrise?.[i];
        const sunsetISO = daily.sunset?.[i];

        // humidity average (from hourly for that day)
        const hIdxs = hourlyIndicesForDate(dateISO);
        let humidityAvg = 0;
        if (hIdxs.length) {
            const sum = hIdxs.reduce((acc, idx) => acc + (hourly.relative_humidity_2m?.[idx] ?? 0), 0);
            humidityAvg = Math.round(sum / hIdxs.length);
        } else {
            humidityAvg = Math.round(current.relative_humidity_2m ?? 0);
        }

        // hourly preview (first 5 hours of that day; for today: next 5 upcoming hours)
        let hourlyPreview: WeatherDay['hourlyForecast'] = [];
        if (hIdxs.length) {
            let slice: number[] = [];
            if (isToday) {
                // find first hourly slot >= now
                const firstIdx = hIdxs.find((idx) => new Date(hourly.time[idx]) >= now) ?? hIdxs[0];
                const startPos = hIdxs.indexOf(firstIdx);
                slice = hIdxs.slice(startPos, startPos + 5);
            } else {
                slice = hIdxs.slice(0, 5);
            }
            hourlyPreview = slice.map((idx) => ({
                time: formatTimeISO(hourly.time[idx]),
                temp: Math.round(hourly.temperature_2m?.[idx] ?? 0),
                condition: getOMIcon(hourly.weather_code?.[idx] ?? 3),
            }));
        }

        const todayCurrentTemp = Math.round(current.temperature_2m ?? NaN);
        const todayWind = Math.round(current.wind_speed_10m ?? windMax);

        const day: WeatherDay = {
            date,
            dayName: isToday ? 'Today' : dayName,
            temperature: {
                min: tMin,
                max: tMax,
                current: isToday && Number.isFinite(todayCurrentTemp) ? todayCurrentTemp : undefined,
            },
            condition: cond,
            precipitation: precipPct,
            humidity: humidityAvg,
            windSpeed: isToday ? todayWind : windMax,
            uvIndex: uvDay,
            sunrise: sunriseISO ? formatTimeISO(sunriseISO) : undefined,
            sunset: sunsetISO ? formatTimeISO(sunsetISO) : undefined,
            hourlyForecast: hourlyPreview,
        };

        days.push(day);
    }

    return days;
};