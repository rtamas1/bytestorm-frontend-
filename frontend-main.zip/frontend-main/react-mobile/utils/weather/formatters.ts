export const formatTimeISO = (iso: string): string => {
    const d = new Date(iso);
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
};

export const formatDateISO = (isoDateOrDateTime: string): { date: string; dayName: string } => {
    const d = new Date(isoDateOrDateTime);
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return {
        date: `${monthNames[d.getMonth()]} ${d.getDate()}`,
        dayName: dayNames[d.getDay()],
    };
};