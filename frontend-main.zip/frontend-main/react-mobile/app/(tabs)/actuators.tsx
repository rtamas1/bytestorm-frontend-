// app/(tabs)/explore.tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { useColorScheme } from '@/hooks/useColorScheme';
import { fetchSensorData, sendActuatorCommand } from '@/services/greenhouse/api';
import { SensorDisplay } from '@/types/greenhouse';
import { mapSensorDataToDisplay } from '@/utils/greenhouse/mappers';

const { width } = Dimensions.get('window');
const GREENHOUSE_ID = 'e663ac91d3824a2c';
const REFRESH_INTERVAL = 30000; // background auto-refresh for non-pending
const CONFIRM_TIMEOUT_MS = 60_000; // 60s max to confirm a change
const POLL_INTERVAL_MS = 1_000; // poll /sensors once per second

const CARD_GAP = 12;
const H_PADDING = 20;
const CARD_WIDTH = (width - H_PADDING * 2 - CARD_GAP) / 2;

type ActuatorId = 'fan' | 'pump' | 'led' | 'servo';

const sensorValueFromData = (id: ActuatorId, data: any): 'ON' | 'OFF' => {
  if (id === 'led') return data?.TESTLED === 1 ? 'ON' : 'OFF';
  if (id === 'fan') return data?.TESTFAN === 1 ? 'ON' : 'OFF';
  if (id === 'pump') return data?.TESTPMP === 1 ? 'ON' : 'OFF';
  if (id === 'servo') return data?.TESTSRV > 0 ? 'ON' : 'OFF';
  return 'OFF';
};

export default function ExploreActuators() {
  const colorScheme = useColorScheme();
  const [allSensors, setAllSensors] = useState<SensorDisplay[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  // Pending tracking
  const [pending, setPending] = useState<Record<ActuatorId, boolean>>({
    fan: false, pump: false, led: false, servo: false,
  });
  const [targetState, setTargetState] = useState<Record<ActuatorId, 'ON' | 'OFF' | null>>({
    fan: null, pump: null, led: null, servo: null,
  });
  const [prevState, setPrevState] = useState<Record<ActuatorId, 'ON' | 'OFF' | null>>({
    fan: null, pump: null, led: null, servo: null,
  });
  const [deadline, setDeadline] = useState<Record<ActuatorId, number | null>>({
    fan: null, pump: null, led: null, servo: null,
  });

  const pollingTimer = useRef<NodeJS.Timer | null>(null);
  const inFlightPoll = useRef(false);

  const load = async () => {
    try {
      setError(null);
      const data = await fetchSensorData(GREENHOUSE_ID);
      const display = mapSensorDataToDisplay(data);
      setAllSensors(display);
      setLastUpdate(new Date());
    } catch (e) {
      console.error('Actuators load error:', e);
      setError('Failed to load actuators');
      setAllSensors((prev) => prev.length ? prev : [
        { id: 'fan', name: 'Fan', value: 'OFF', icon: '🌀', color: '#95a5a6', status: 'neutral' },
        { id: 'pump', name: 'Pump', value: 'OFF', icon: '⛽', color: '#95a5a6', status: 'neutral' },
        { id: 'led', name: 'LED', value: 'OFF', icon: '💡', color: '#95a5a6', status: 'neutral' },
        { id: 'servo', name: 'Servo', value: 'OFF', icon: '⚙️', color: '#95a5a6', status: 'neutral' },
      ]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load + passive auto-refresh
  useEffect(() => {
    load();
    const id = setInterval(() => {
      // avoid passive refresh while any actuator is pending (poller handles it)
      const anyPending = Object.values(pending).some(Boolean);
      if (!anyPending) load();
    }, REFRESH_INTERVAL);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Global 1s polling loop whenever any actuator is pending
  useEffect(() => {
    const anyPending = Object.values(pending).some(Boolean);

    const startPolling = () => {
      if (pollingTimer.current) return;
      pollingTimer.current = setInterval(async () => {
        if (inFlightPoll.current) return;
        inFlightPoll.current = true;
        try {
          const data = await fetchSensorData(GREENHOUSE_ID);

          // Update the sensor tiles live
          const display = mapSensorDataToDisplay(data);
          setAllSensors(display);
          setLastUpdate(new Date());

          // Evaluate each pending actuator
          setPending((prevPending) => {
            const updated = { ...prevPending };
            let changedSomething = false;

            (Object.keys(prevPending) as ActuatorId[]).forEach((id) => {
              if (!prevPending[id]) return;
              const currentVal = sensorValueFromData(id, data);
              const expected = targetState[id];
              const dl = deadline[id] ?? 0;
              const now = Date.now();

              // success: reached expected state
              if (expected && currentVal === expected) {
                updated[id] = false;
                // clear metadata
                setTargetState((t) => ({ ...t, [id]: null }));
                setPrevState((p) => ({ ...p, [id]: null }));
                setDeadline((d) => ({ ...d, [id]: null }));
                changedSomething = true;
                return;
              }

              // timeout: revert and alert
              if (dl && now >= dl) {
                updated[id] = false;
                const prev = prevState[id] || 'OFF';
                // revert optimistic UI
                setAllSensors((prevSensors) =>
                  prevSensors.map((s) => s.id === id ? {
                    ...s,
                    value: prev,
                    color: prev === 'ON' ? '#27ae60' : '#95a5a6',
                  } : s)
                );
                setTargetState((t) => ({ ...t, [id]: null }));
                setPrevState((p) => ({ ...p, [id]: null }));
                setDeadline((d) => ({ ...d, [id]: null }));
                changedSomething = true;
                Alert.alert('Not applied', `The ${id} did not change to ${expected} within 60s.`);
              }
            });

            // stop polling if nothing pending anymore
            if (changedSomething) {
              const stillPending = Object.values(updated).some(Boolean);
              if (!stillPending) {
                if (pollingTimer.current) {
                  clearInterval(pollingTimer.current);
                  pollingTimer.current = null;
                }
              }
            }
            return updated;
          });
        } catch (e) {
          // ignore transient poll errors
        } finally {
          inFlightPoll.current = false;
        }
      }, POLL_INTERVAL_MS);
    };

    const stopPolling = () => {
      if (pollingTimer.current) {
        clearInterval(pollingTimer.current);
        pollingTimer.current = null;
      }
    };

    if (anyPending) startPolling();
    else stopPolling();

    return () => stopPolling();
  }, [pending, targetState, deadline]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const actuators = useMemo(
    () => allSensors.filter((s) => ['fan', 'pump', 'led', 'servo'].includes(s.id)),
    [allSensors]
  ) as (SensorDisplay & { id: ActuatorId })[];

  const lastUpdateText = useMemo(() => {
    if (!lastUpdate) return '';
    const now = new Date();
    const diff = Math.floor((now.getTime() - lastUpdate.getTime()) / 1000);
    if (diff < 60) return `Updated ${diff}s ago`;
    if (diff < 3600) return `Updated ${Math.floor(diff / 60)}m ago`;
    return `Updated ${Math.floor(diff / 3600)}h ago`;
  }, [lastUpdate]);

  const optimisticSet = (id: ActuatorId, next: 'ON' | 'OFF') => {
    setAllSensors((prev) =>
      prev.map((s) => (s.id === id ? { ...s, value: next, color: next === 'ON' ? '#27ae60' : '#95a5a6' } : s))
    );
  };

  const handleToggle = async (id: ActuatorId) => {
    if (pending[id]) return;
    const target = actuators.find((a) => a.id === id);
    if (!target) return;

    const was = target.value as 'ON' | 'OFF';
    const toServer = was === 'ON' ? 'off' : 'on';
    const toLabel = was === 'ON' ? 'OFF' : 'ON';

    // mark pending & set metadata before calling the API
    setPrevState((p) => ({ ...p, [id]: was }));
    setTargetState((t) => ({ ...t, [id]: toLabel }));
    setDeadline((d) => ({ ...d, [id]: Date.now() + CONFIRM_TIMEOUT_MS }));
    setPending((p) => ({ ...p, [id]: true }));
    optimisticSet(id, toLabel);

    try {
      await sendActuatorCommand(GREENHOUSE_ID, id, toServer);
      // Do not force-load here; the poller is running each second and will confirm/revert.
    } catch (e: any) {
      // immediate failure — revert and clear pending for this actuator
      setPending((p) => ({ ...p, [id]: false }));
      setTargetState((t) => ({ ...t, [id]: null }));
      setDeadline((d) => ({ ...d, [id]: null }));
      optimisticSet(id, was);
      Alert.alert('Command failed', e?.message || 'Could not send command.');
    }
  };

  const secondsLeft = (id: ActuatorId) => {
    const dl = deadline[id];
    if (!dl) return 0;
    const s = Math.ceil((dl - Date.now()) / 1000);
    return Math.max(0, s);
  };

  return (
    <SafeAreaView
      style={[
        styles.container,
        { backgroundColor: colorScheme === 'dark' ? '#000' : '#f0f4f7' },
      ]}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#007AFF" />}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colorScheme === 'dark' ? '#fff' : '#2c3e50' }]}>
            Actuators
          </Text>
          {!!lastUpdate && (
            <Text style={[styles.subtitle, { color: colorScheme === 'dark' ? '#666' : '#7f8c8d' }]}>
              {lastUpdateText}
            </Text>
          )}
        </View>

        {loading ? (
          <View style={styles.loadingContainer}>
            <Text style={[styles.loadingText, { color: colorScheme === 'dark' ? '#fff' : '#000' }]}>
              Loading…
            </Text>
          </View>
        ) : error ? (
          <View style={styles.errorContainer}>
            <Text style={[styles.errorText, { color: colorScheme === 'dark' ? '#fff' : '#e74c3c' }]}>
              ⚠️ {error}
            </Text>
          </View>
        ) : (
          <View style={styles.grid}>
            {actuators.map((a) => {
              const isOn = a.value === 'ON';
              const isPending = pending[a.id];
              const sLeft = secondsLeft(a.id);

              return (
                <TouchableOpacity
                  key={a.id}
                  activeOpacity={0.8}
                  disabled={isPending}
                  onPress={() => handleToggle(a.id)}
                  style={[
                    styles.card,
                    {
                      width: CARD_WIDTH,
                      backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white',
                      borderColor: isOn ? `${a.color}55` : 'transparent',
                      borderWidth: isOn ? 1 : 0,
                      opacity: isPending ? 0.85 : 1,
                    },
                  ]}
                >
                  <Text style={styles.icon}>{a.icon}</Text>
                  <Text style={[styles.name, { color: colorScheme === 'dark' ? '#ccc' : '#7f8c8d' }]}>
                    {a.name}
                  </Text>

                  <View
                    style={[
                      styles.badge,
                      {
                        backgroundColor: isOn ? a.color : (colorScheme === 'dark' ? '#2a2a2a' : '#ecf0f1'),
                      },
                    ]}
                  >
                    {isPending ? (
                      <View style={styles.pendingRow}>
                        <ActivityIndicator size="small" color={isOn ? '#fff' : '#7f8c8d'} />
                        <Text style={[styles.pendingText, { color: isOn ? '#fff' : (colorScheme === 'dark' ? '#aaa' : '#7f8c8d') }]}>
                          applying… {sLeft}s
                        </Text>
                      </View>
                    ) : (
                      <Text
                        style={[
                          styles.badgeText,
                          { color: isOn ? 'white' : (colorScheme === 'dark' ? '#aaa' : '#7f8c8d') },
                        ]}
                      >
                        {a.value}
                      </Text>
                    )}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: H_PADDING, paddingTop: 16, paddingBottom: 8 },
  title: { fontSize: 28, fontWeight: 'bold' },
  subtitle: { marginTop: 6, fontSize: 12 },

  loadingContainer: { paddingVertical: 100, alignItems: 'center' },
  loadingText: { fontSize: 16 },
  errorContainer: { paddingVertical: 80, alignItems: 'center' },
  errorText: { fontSize: 16 },

  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: H_PADDING,
    paddingBottom: 20,
    gap: CARD_GAP,
  },
  card: {
    borderRadius: 18,
    paddingVertical: 22,
    paddingHorizontal: 16,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  icon: { fontSize: 42, marginBottom: 8 },
  name: { fontSize: 14, marginBottom: 10, fontWeight: '600' },
  badge: {
    borderRadius: 999,
    paddingHorizontal: 18,
    paddingVertical: 8,
    minWidth: 120,
    alignItems: 'center',
  },
  badgeText: { fontSize: 16, fontWeight: '800', letterSpacing: 1 },
  pendingRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pendingText: { fontSize: 14, fontWeight: '700' },
});
