import { useColorScheme } from '@/hooks/useColorScheme';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useVideoPlayer, VideoView } from 'expo-video';
import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import SensorGrid from '@/components/greenhouse/SensorGrid';
import { fetchSensorData } from '@/services/greenhouse/api';
import { SensorDisplay } from '@/types/greenhouse';
import { mapSensorDataToDisplay } from '@/utils/greenhouse/mappers';

const { width } = Dimensions.get('window');
const GREENHOUSE_ID = 'e663ac91d3824a2c';
const REFRESH_INTERVAL = 30000; // 30 seconds

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const [sensors, setSensors] = useState<SensorDisplay[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  // Initialize video player
  const player = useVideoPlayer('https://dm0qx8t0i9gc9.cloudfront.net/watermarks/video/BgrICs-NZj4hksnn3/videoblocks-aerial-footage-in-a-greenhouse-with-moder-agriculture-technology-for-growing-green-salad_r7qr34uus__789bf4e34ba620421521574703463dc6__P360.mp4', player => {
    player.loop = true;
    player.muted = true;
    player.play();
  });

  // Weather data (could be from API too)
  const weatherData = {
    temperature: 24,
    condition: 'sunny' as 'sunny' | 'rainy' | 'cloudy' | 'partly-cloudy' | 'snowy',
    location: 'Greenhouse Location',
  };

  const weatherIcons = {
    sunny: '☀️',
    rainy: '🌧️',
    cloudy: '☁️',
    'partly-cloudy': '⛅',
    snowy: '❄️',
  };

  const weatherGradients = {
    sunny: ['#FFB75E', '#ED8F03'],
    rainy: ['#4CA1AF', '#2C3E50'],
    cloudy: ['#757F9A', '#D7DDE8'],
    'partly-cloudy': ['#89F7FE', '#66A6FF'],
    snowy: ['#E6DADA', '#274046'],
  };

  // Fetch sensor data
  const loadSensorData = async () => {
    try {
      setError(null);
      const data = await fetchSensorData(GREENHOUSE_ID);
      const displaySensors = mapSensorDataToDisplay(data);
      setSensors(displaySensors);
      setLastUpdate(new Date());
    } catch (err) {
      console.error('Error loading sensors:', err);
      setError('Failed to load sensor data');
      // Use mock data as fallback
      setSensors([
        { id: '1', name: 'Air Temp', value: '--°C', icon: '🌡️', color: '#e74c3c' },
        { id: '2', name: 'Humidity', value: '--%', icon: '💧', color: '#3498db' },
        { id: '3', name: 'Light', value: '-- lux', icon: '☀️', color: '#f39c12' },
        { id: '4', name: 'Air Quality', value: '--', icon: '💨', color: '#95a5a6' },
      ]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load and auto-refresh
  useEffect(() => {
    loadSensorData();

    // Set up auto-refresh
    const interval = setInterval(loadSensorData, REFRESH_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  // Pull to refresh
  const onRefresh = () => {
    setRefreshing(true);
    loadSensorData();
  };

  // Format last update time
  const formatLastUpdate = () => {
    if (!lastUpdate) return '';
    const now = new Date();
    const diff = Math.floor((now.getTime() - lastUpdate.getTime()) / 1000);

    if (diff < 60) return `Updated ${diff}s ago`;
    if (diff < 3600) return `Updated ${Math.floor(diff / 60)}m ago`;
    return `Updated ${Math.floor(diff / 3600)}h ago`;
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colorScheme === 'dark' ? '#000' : '#f0f4f7' }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#007AFF"
          />
        }
      >
        {/* Weather Card */}
        <TouchableOpacity
          onPress={() => router.push('/weather-forecast')}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={weatherGradients[weatherData.condition]}
            style={styles.weatherCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.weatherContent}>
              <View style={styles.weatherLeft}>
                <Text style={styles.weatherLocation}>{weatherData.location}</Text>
                <Text style={styles.weatherTemp}>{weatherData.temperature}°C</Text>
                <Text style={styles.weatherCondition}>
                  {weatherData.condition.charAt(0).toUpperCase() +
                    weatherData.condition.slice(1).replace('-', ' ')}
                </Text>
              </View>
              <View style={styles.weatherRight}>
                <Text style={styles.weatherIcon}>
                  {weatherIcons[weatherData.condition]}
                </Text>
              </View>
            </View>
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.videoWrapper}>
          <TouchableOpacity
            onPress={() => router.push('/gauges')}
            activeOpacity={0.8}
            style={[
              styles.titleContainer,
              { backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white' }
            ]}
          >
            <View style={styles.titleRow}>
              <View>
                <Text style={[styles.titleText, { color: colorScheme === 'dark' ? '#fff' : '#2c3e50' }]}>
                  Greenhouse 1
                </Text>
                {lastUpdate && (
                  <Text style={[styles.updateText, { color: colorScheme === 'dark' ? '#666' : '#999' }]}>
                    {formatLastUpdate()}
                  </Text>
                )}
              </View>
              <View style={styles.gaugeButton}>
                <Text style={styles.gaugeIcon}>📊</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Video */}
          <View style={styles.videoContainer}>
            <VideoView
              style={styles.video}
              player={player}
              allowsFullscreen
              allowsPictureInPicture
              contentFit="cover"
              nativeControls
            />
            <View style={styles.videoOverlay} pointerEvents="none">
              <Text style={styles.videoText}>Greenhouse Live Feed</Text>
            </View>
          </View>

          {/* Real Sensor Data Grid */}
          <SensorGrid
            sensors={sensors}
            loading={loading}
            error={error}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 20
  },
  weatherCard: {
    margin: 20,
    borderRadius: 20,
    padding: 25,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
  },
  weatherContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  weatherLeft: {
    flex: 1,
  },
  weatherLocation: {
    color: 'white',
    fontSize: 14,
    opacity: 0.9,
    marginBottom: 5,
  },
  weatherTemp: {
    color: 'white',
    fontSize: 48,
    fontWeight: 'bold',
    marginVertical: 5,
  },
  weatherCondition: {
    color: 'white',
    fontSize: 18,
    opacity: 0.9,
  },
  weatherRight: {
    marginLeft: 20,
  },
  weatherIcon: {
    fontSize: 80,
  },
  titleContainer: {
    paddingHorizontal: 20,
    paddingVertical: 18,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 26,
    fontWeight: 'bold',
  },
  updateText: {
    fontSize: 12,
    marginTop: 4,
  },
  gaugeButton: {
    padding: 5,
  },
  gaugeIcon: {
    fontSize: 28,
  },
  videoWrapper: {
    marginHorizontal: 20,
    marginBottom: 30,
    borderRadius: 15,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  videoContainer: {
    position: 'relative',
    width: width - 40,
    height: 200,
    backgroundColor: '#000',
    overflow: 'hidden'
  },
  video: {
    width: '100%',
    height: '100%',
  },
  videoOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 10,
  },
  videoText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});