import { Tabs } from 'expo-router';
import React from 'react';
import { Platform, Text, TouchableOpacity } from 'react-native';

import { HapticTab } from '@/components/HapticTab';
import { IconSymbol } from '@/components/ui/IconSymbol';
import TabBarBackground from '@/components/ui/TabBarBackground';
import { Colors } from '@/constants/colors';
import { useAuth } from '@/contexts/auth-context';
import { useColorScheme } from '@/hooks/useColorScheme';

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const { logout } = useAuth();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
        headerShown: true,
        tabBarButton: HapticTab,
        tabBarBackground: TabBarBackground,
        tabBarStyle: Platform.select({
          ios: {
            position: 'absolute',
          },
          default: {},
        }),
        headerRight: () => (
          <TouchableOpacity
            onPress={logout}
            style={{ marginRight: 15, padding: 5 }}
          >
            <Text style={{
              color: Colors[colorScheme ?? 'light'].tint,
              fontSize: 16,
              fontWeight: '600'
            }}>
              Logout
            </Text>
          </TouchableOpacity>
        ),
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} />,
        }}
      />
      <Tabs.Screen
        name="actuators"
        options={{
          title: 'Actuators',
          tabBarIcon: ({ color }) => <IconSymbol size={28} name="sensor.fill" color={color} />,
        }}
      />
    </Tabs>
  );
}