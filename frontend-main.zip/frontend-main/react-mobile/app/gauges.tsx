import { useColorScheme } from '@/hooks/useColorScheme';
import { Stack, router } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Svg, { Circle, G, Path, Text as SvgText } from 'react-native-svg';

import { fetchSensorData } from '@/services/greenhouse/api';
import { SensorData } from '@/types/greenhouse';

const { width } = Dimensions.get('window');
const CARD_SIZE = (width - 50) / 2;
const GAUGE_SIZE = CARD_SIZE * 0.75;
const GREENHOUSE_ID = 'e663ac91d3824a2c';
const REFRESH_INTERVAL = 30000;

type GaugeStatus = 'good' | 'warning' | 'danger' | 'neutral';

type GaugeSegment = { from: number; to: number; color: string };

interface GaugeConfig {
  id: string;
  value: number;
  minValue: number;
  maxValue: number;
  unit: string;
  label: string;
  icon: string;
  statusText?: string;
  status?: GaugeStatus;
  segments: GaugeSegment[];
}

interface GaugeProps {
  value: number;
  minValue?: number;
  maxValue?: number;
  unit: string;
  label: string;
  icon: string;
  status?: string;
  colorScheme?: 'light' | 'dark';
  segments: GaugeSegment[];
}

const Gauge: React.FC<GaugeProps> = ({
  value,
  minValue = 0,
  maxValue = 100,
  unit,
  label,
  icon,
  status,
  colorScheme = 'light',
  segments,
}) => {
  const startAngle = -135;
  const endAngle = 135;
  const span = endAngle - startAngle;
  const gaugeSize = GAUGE_SIZE;
  const radius = gaugeSize / 2 - 28;
  const strokeWidth = 8;

  const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n));
  const safeMin = Math.min(minValue, maxValue);
  const safeMax = Math.max(minValue, maxValue);
  const denom = Math.max(1e-6, safeMax - safeMin); // avoid /0
  const toAngle = (v: number) => startAngle + ((clamp(v, safeMin, safeMax) - safeMin) / denom) * span;

  const needleAngle = toAngle(value);
  const needleRad = (needleAngle * Math.PI) / 180;
  const needleEndX = gaugeSize / 2 + radius * 0.8 * Math.cos(needleRad);
  const needleEndY = gaugeSize / 2 + radius * 0.8 * Math.sin(needleRad);

  const createArcPathByAngle = (a1: number, a2: number) => {
    const toXY = (a: number) => {
      const r = (a * Math.PI) / 180;
      return {
        x: gaugeSize / 2 + radius * Math.cos(r),
        y: gaugeSize / 2 + radius * Math.sin(r),
      };
    };
    const A1 = Math.max(startAngle, Math.min(endAngle, a1));
    const A2 = Math.max(startAngle, Math.min(endAngle, a2));
    if (A2 <= A1) return null;
    const p1 = toXY(A1);
    const p2 = toXY(A2);
    const largeArc = Math.abs(A2 - A1) > 180 ? 1 : 0;
    return `M ${p1.x} ${p1.y} A ${radius} ${radius} 0 ${largeArc} 1 ${p2.x} ${p2.y}`;
  };

  const formatValue = (n: number) =>
    Number.isFinite(n) ? (Math.abs(n % 1) < 1e-6 ? `${n}` : n.toFixed(1)) : '--';

  // Background: draw each segment in its color at low opacity
  const backgroundArcs = segments.map((seg, idx) => {
    const d = createArcPathByAngle(toAngle(seg.from), toAngle(seg.to));
    return d ? (
      <Path key={`bg-${idx}`} d={d} stroke={seg.color} strokeWidth={strokeWidth} fill="none" strokeLinecap="round" opacity={0.25} />
    ) : null;
  });

  // Active arcs: draw up to the current value, segment by segment
  const activeArcs = segments.map((seg, idx) => {
    const segStart = toAngle(seg.from);
    const segEnd = toAngle(seg.to);
    const activeEnd = Math.min(segEnd, needleAngle);
    if (activeEnd <= segStart) return null;
    const d = createArcPathByAngle(segStart, activeEnd);
    return d ? <Path key={`act-${idx}`} d={d} stroke={seg.color} strokeWidth={strokeWidth} fill="none" strokeLinecap="round" /> : null;
  });

  return (
    <View style={styles.gaugeContainer}>
      <Svg width={gaugeSize} height={gaugeSize}>
        {backgroundArcs}
        {activeArcs}

        {/* Needle */}
        <G>
          <Path
            d={`M ${gaugeSize / 2} ${gaugeSize / 2} L ${needleEndX} ${needleEndY}`}
            stroke={colorScheme === 'dark' ? '#fff' : '#000'}
            strokeWidth={3}
            strokeLinecap="round"
          />
          <Circle cx={gaugeSize / 2} cy={gaugeSize / 2} r={6} fill={colorScheme === 'dark' ? '#fff' : '#000'} />
        </G>

        {/* Scale labels */}
        <SvgText
          x={8}
          y={gaugeSize / 2 + 5}
          fontSize="10"
          fill={colorScheme === 'dark' ? '#999' : '#666'}
          textAnchor="start"
        >
          {safeMin}
        </SvgText>
        <SvgText
          x={gaugeSize}
          y={gaugeSize / 2 + 5}
          fontSize="10"
          fill={colorScheme === 'dark' ? '#999' : '#666'}
          textAnchor="end"
        >
          {safeMax}
        </SvgText>
      </Svg>

      <Text style={[styles.gaugeValue, { color: colorScheme === 'dark' ? '#fff' : '#000' }]}>
        {formatValue(value)}
        {unit}
      </Text>
      <View style={styles.gaugeLabelContainer}>
        <Text style={styles.gaugeEmoji}>{icon}</Text>
        <Text style={[styles.gaugeLabel, { color: colorScheme === 'dark' ? '#999' : '#666' }]}>{label}</Text>
      </View>
      {!!status && <Text style={[styles.gaugeStatus, { color: colorScheme === 'dark' ? '#999' : '#666' }]}>{status}</Text>}
    </View>
  );
};

export default function GaugesScreen() {
  const colorScheme = useColorScheme();
  const [data, setData] = useState<SensorData | null>(null);
  const [gauges, setGauges] = useState<GaugeConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const load = async () => {
    try {
      setError(null);
      const d = await fetchSensorData(GREENHOUSE_ID);
      setData(d);
      setLastUpdate(new Date());
    } catch (e: any) {
      console.error('Gauge load error:', e);
      setError('Failed to load sensor data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(load, REFRESH_INTERVAL);
    return () => clearInterval(id);
  }, []);

  // Define color helpers
  const C = {
    green: '#27ae60',
    yellow: '#f1c40f',
    orange: '#e67e22',
    red: '#e74c3c',
    purple: '#8e44ad',
    maroon: '#6C0A0A',
    blue: '#3498db',
    grey: '#95a5a6',
  };

  // Map SensorData -> 8 gauges with per-metric segments
  useEffect(() => {
    if (!data) return;

    const gaugesNew: GaugeConfig[] = [
      // Air Temperature (°C): 0–10 red, 10–15 orange, 15–30 green, 30–35 orange, 35–50 red
      {
        id: 'air-temp',
        label: 'Air Temp',
        icon: '🌡️',
        unit: '°C',
        value: data.TEMPAER ?? 0,
        minValue: 0,
        maxValue: 50,
        status:
          data.TEMPAER < 15 ? 'warning' : data.TEMPAER > 30 ? 'warning' : 'good',
        statusText:
          data.TEMPAER < 15 ? 'Too cold' : data.TEMPAER > 30 ? 'Too hot' : 'Optim',
        segments: [
          { from: 0, to: 10, color: C.red },
          { from: 10, to: 15, color: C.orange },
          { from: 15, to: 30, color: C.green },
          { from: 30, to: 35, color: C.orange },
          { from: 35, to: 50, color: C.red },
        ],
      },

      // Air Humidity (%): 0–30 red, 30–40 orange, 40–70 green, 70–80 orange, 80–100 red
      {
        id: 'air-humidity',
        label: 'Air Humidity',
        icon: '💧',
        unit: '%',
        value: data.UMDTAER ?? 0,
        minValue: 0,
        maxValue: 100,
        status:
          data.UMDTAER < 40 ? 'warning' : data.UMDTAER > 70 ? 'warning' : 'good',
        statusText:
          data.UMDTAER < 40 ? 'Too dry' : data.UMDTAER > 70 ? 'Too wet' : 'Optim',
        segments: [
          { from: 0, to: 30, color: C.red },
          { from: 30, to: 40, color: C.orange },
          { from: 40, to: 70, color: C.green },
          { from: 70, to: 80, color: C.orange },
          { from: 80, to: 100, color: C.red },
        ],
      },

      // Light (lux): 0–50 red, 50–100 orange, 100–800 green, 800–1200 orange, 1200–2000 red
      {
        id: 'light',
        label: 'Light',
        icon: '☀️',
        unit: ' lux',
        value: Math.max(0, Math.round(data.ILUMINARE ?? 0)),
        minValue: 0,
        maxValue: 2000,
        status: (data.ILUMINARE ?? 0) < 100 ? 'warning' : (data.ILUMINARE ?? 0) > 1200 ? 'warning' : 'good',
        statusText:
          (data.ILUMINARE ?? 0) < 100 ? 'Low light' : (data.ILUMINARE ?? 0) > 1200 ? 'Very powerful' : 'Good',
        segments: [
          { from: 0, to: 50, color: C.red },
          { from: 50, to: 100, color: C.orange },
          { from: 100, to: 800, color: C.green },
          { from: 800, to: 1200, color: C.orange },
          { from: 1200, to: 2000, color: C.red },
        ],
      },

      // Air Quality (AQI 0–500): Good→Hazardous
      {
        id: 'air-quality',
        label: 'Air quality',
        icon: '💨',
        unit: ' AQI',
        value: Math.max(0, Math.round(data.CALITAER ?? 0)),
        minValue: 0,
        maxValue: 500,
        status:
          (data.CALITAER ?? 0) <= 50
            ? 'good'
            : (data.CALITAER ?? 0) <= 100
            ? 'warning'
            : 'danger',
        statusText:
          (data.STAREAER || '—').charAt(0).toUpperCase() + (data.STAREAER || '—').slice(1),
        segments: [
          { from: 0, to: 50, color: C.green },     // Good
          { from: 50, to: 100, color: C.yellow },  // Moderate
          { from: 100, to: 150, color: C.orange }, // USG
          { from: 150, to: 200, color: C.red },    // Unhealthy
          { from: 200, to: 300, color: C.purple }, // Very Unhealthy
          { from: 300, to: 500, color: C.maroon }, // Hazardous
        ],
      },

      // Soil 1 (%)
      {
        id: 'soil-1',
        label: 'Soil humidity 1',
        icon: '🌱',
        unit: '%',
        value: data.UMDTSOL1 ?? 0,
        minValue: 0,
        maxValue: 100,
        status:
          data.UMDTSOL1 < 30 ? 'warning' : data.UMDTSOL1 > 80 ? 'warning' : 'good',
        statusText:
          data.UMDTSOL1 < 30 ? 'Too dry' : data.UMDTSOL1 > 80 ? 'Too wet' : 'Optim',
        segments: [
          { from: 0, to: 20, color: C.red },
          { from: 20, to: 30, color: C.orange },
          { from: 30, to: 80, color: C.green },
          { from: 80, to: 90, color: C.orange },
          { from: 90, to: 100, color: C.red },
        ],
      },

      // Soil 2 (%)
      {
        id: 'soil-2',
        label: 'Soil humidity 2',
        icon: '🌿',
        unit: '%',
        value: data.UMDTSOL2 ?? 0,
        minValue: 0,
        maxValue: 100,
        status:
          data.UMDTSOL2 < 30 ? 'warning' : data.UMDTSOL2 > 80 ? 'warning' : 'good',
        statusText:
          data.UMDTSOL2 < 30 ? 'Too dry' : data.UMDTSOL2 > 80 ? 'Too wet' : 'Optim',
        segments: [
          { from: 0, to: 20, color: C.red },
          { from: 20, to: 30, color: C.orange },
          { from: 30, to: 80, color: C.green },
          { from: 80, to: 90, color: C.orange },
          { from: 90, to: 100, color: C.red },
        ],
      },

      // Water Level (%)
      {
        id: 'water-level',
        label: 'Water level',
        icon: '💦',
        unit: '%',
        value: data.NIVELAPA ?? 0,
        minValue: 0,
        maxValue: 100,
        status: data.NIVELAPA < 20 ? 'danger' : data.NIVELAPA < 40 ? 'warning' : 'good',
        statusText: data.NIVELAPA < 20 ? 'Critical level' : data.NIVELAPA < 40 ? 'Too low' : 'Good',
        segments: [
          { from: 0, to: 20, color: C.red },
          { from: 20, to: 40, color: C.orange },
          { from: 40, to: 100, color: C.green },
        ],
      },

      // Excess Water / Drainage (%)
      {
        id: 'excess-water',
        label: 'Drainage',
        icon: '🚰',
        unit: '%',
        value: data.EXCESAPA ?? 0,
        minValue: 0,
        maxValue: 100,
        status: data.EXCESAPA > 75 ? 'danger' : data.EXCESAPA > 50 ? 'warning' : 'good',
        statusText: data.EXCESAPA > 50 ? 'Excess detected' : 'OK',
        segments: [
          { from: 0, to: 50, color: C.green },
          { from: 50, to: 75, color: C.orange },
          { from: 75, to: 100, color: C.red },
        ],
      },
    ];

    setGauges(gaugesNew);
  }, [data]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const lastUpdateText = useMemo(() => {
    if (!lastUpdate) return '';
    const now = new Date();
    const diff = Math.floor((now.getTime() - lastUpdate.getTime()) / 1000);
    if (diff < 60) return `Actualizat acum ${diff}s`;
    if (diff < 3600) return `Actualizat acum ${Math.floor(diff / 60)}m`;
    return `Actualizat acum ${Math.floor(diff / 3600)}h`;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastUpdate?.getTime()]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colorScheme === 'dark' ? '#000' : '#f0f4f7' }]}>
      <Stack.Screen
        options={{
          title: 'Greenhouse 1 Sensors',
          headerLeft: () => (
            <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
              <Text style={styles.backIcon}>⬅️</Text>
            </TouchableOpacity>
          ),
        }}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#007AFF" />}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colorScheme === 'dark' ? '#fff' : '#2c3e50' }]}>Sensori</Text>
          {!!lastUpdate && (
            <Text style={[styles.updateText, { color: colorScheme === 'dark' ? '#666' : '#7f8c8d' }]}>{lastUpdateText}</Text>
          )}
        </View>

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#007AFF" />
            <Text style={[styles.loadingText, { color: colorScheme === 'dark' ? '#fff' : '#000' }]}>Se încarcă senzorii...</Text>
          </View>
        ) : error ? (
          <View style={styles.errorContainer}>
            <Text style={[styles.errorText, { color: colorScheme === 'dark' ? '#fff' : '#e74c3c' }]}>⚠️ {error}</Text>
          </View>
        ) : (
          <View style={styles.gaugesGrid}>
            {gauges.map((g) => (
              <View
                key={g.id}
                style={[
                  styles.card,
                  {
                    backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white',
                    borderWidth: g.status === 'danger' ? 1 : 0,
                    borderColor: g.status === 'danger' ? '#e74c3c55' : 'transparent',
                  },
                ]}
              >
                <Gauge
                  value={g.value}
                  minValue={g.minValue}
                  maxValue={g.maxValue}
                  unit={g.unit}
                  label={g.label}
                  icon={g.icon}
                  status={g.statusText}
                  colorScheme={colorScheme}
                  segments={g.segments}
                />
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { padding: 20, alignItems: 'center' },
  title: { fontSize: 28, fontWeight: 'bold' },
  updateText: { marginTop: 6, fontSize: 12 },
  backButton: { padding: 5 },
  backIcon: { fontSize: 24 },
  gaugesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 10,
    paddingBottom: 10,
    justifyContent: 'space-between',
  },
  card: {
    width: CARD_SIZE,
    marginBottom: 15,
    marginHorizontal: 5,
    padding: 15,
    borderRadius: 20,
    alignItems: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  gaugeContainer: { alignItems: 'center' },
  gaugeValue: { fontSize: 22, fontWeight: 'bold', marginTop: -10 },
  gaugeLabelContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 8, gap: 5 },
  gaugeEmoji: { fontSize: 20 },
  gaugeLabel: { fontSize: 16 },
  gaugeStatus: { fontSize: 13, marginTop: 5, textAlign: 'center' },

  loadingContainer: { paddingVertical: 100, alignItems: 'center' },
  loadingText: { marginTop: 10, fontSize: 16 },
  errorContainer: { paddingVertical: 80, alignItems: 'center' },
  errorText: { fontSize: 16 },
});
