import { useColorScheme } from '@/hooks/useColorScheme';
import { Stack, router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    SafeAreaView,
    ScrollView,
    Text,
    TouchableOpacity,
    View
} from 'react-native';

import DayWeatherCard from '@/components/weather/DayWeatherCard';
import DetailedWeatherCard from '@/components/weather/DetailedWeatherCard';
import LocationSearch from '@/components/weather/LocationSearch';

import { DEFAULT_LOCATION } from '@/constants/weather';
import { fetchWeatherData } from '@/services/weather/api';
import { styles } from '@/styles/weather/weather-screen.styles';
import { Location, WeatherDay } from '@/types/weather';

export default function WeatherForecastScreen() {
    const colorScheme = useColorScheme();
    const [selectedDayIndex, setSelectedDayIndex] = useState(0);
    const [weatherForecast, setWeatherForecast] = useState<WeatherDay[]>([]);
    const [loading, setLoading] = useState(true);
    const [currentLocation, setCurrentLocation] = useState<Location>(DEFAULT_LOCATION);

    const loadWeatherData = async (location: Location) => {
        setLoading(true);
        try {
            const data = await fetchWeatherData(location.lat, location.lon);
            setWeatherForecast(data);
            setSelectedDayIndex(0); // Reset to first day when location changes
        } catch (error) {
            console.error('Error loading weather:', error);
            Alert.alert('Error', 'Failed to fetch weather data.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadWeatherData(currentLocation);
    }, []);

    const handleLocationChange = (location: Location) => {
        setCurrentLocation(location);
        loadWeatherData(location);
    };

    const selectedWeather = weatherForecast[selectedDayIndex] || null;

    return (
        <SafeAreaView style={[styles.container, {
            backgroundColor: colorScheme === 'dark' ? '#000' : '#f0f4f7'
        }]}>
            <Stack.Screen
                options={{
                    title: 'Weather Forecast',
                    headerLeft: () => (
                        <TouchableOpacity
                            onPress={() => router.back()}
                            style={styles.backButton}
                        >
                            <Text style={styles.backIcon}>←</Text>
                        </TouchableOpacity>
                    ),
                }}
            />

            <ScrollView showsVerticalScrollIndicator={false}>
                <LocationSearch
                    currentLocation={currentLocation}
                    onLocationSelect={handleLocationChange}
                />

                {loading ? (
                    <View style={styles.loadingContainer}>
                        <ActivityIndicator size="large" color="#007AFF" />
                        <Text style={[styles.loadingText, {
                            color: colorScheme === 'dark' ? '#fff' : '#000'
                        }]}>
                            Loading weather data...
                        </Text>
                    </View>
                ) : selectedWeather ? (
                    <>
                        <DetailedWeatherCard weather={selectedWeather} />

                        <View style={styles.forecastSection}>
                            <Text style={[styles.forecastTitle, {
                                color: colorScheme === 'dark' ? '#fff' : '#2c3e50'
                            }]}>
                                {weatherForecast.length}-Day Forecast
                            </Text>
                            {weatherForecast.map((day, index) => (
                                <DayWeatherCard
                                    key={index}
                                    weather={day}
                                    index={index}
                                    isSelected={selectedDayIndex === index}
                                    onPress={() => setSelectedDayIndex(index)}
                                />
                            ))}
                        </View>
                    </>
                ) : (
                    <View style={styles.errorContainer}>
                        <Text style={[styles.errorText, {
                            color: colorScheme === 'dark' ? '#fff' : '#000'
                        }]}>
                            No weather data available
                        </Text>
                    </View>
                )}
            </ScrollView>
        </SafeAreaView>
    );
}