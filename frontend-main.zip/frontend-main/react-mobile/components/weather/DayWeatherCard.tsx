import { WEATHER_ICONS } from '@/constants/weather';
import { useColorScheme } from '@/hooks/useColorScheme';
import { styles } from '@/styles/weather/weather-card.styles';
import { WeatherDay } from '@/types/weather';
import React from 'react';
import { Text, TouchableOpacity, View } from 'react-native';

interface Props {
    weather: WeatherDay;
    index: number;
    isSelected: boolean;
    onPress: () => void;
}

export default function DayWeatherCard({ weather, index, isSelected, onPress }: Props) {
    const colorScheme = useColorScheme();

    return (
        <TouchableOpacity
            style={[
                styles.dayCard,
                {
                    backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white',
                    borderWidth: isSelected ? 2 : 0,
                    borderColor: isSelected ? '#007AFF' : 'transparent',
                }
            ]}
            onPress={onPress}
            activeOpacity={0.8}
        >
            <View style={styles.dayLeft}>
                <Text style={[
                    styles.dayName,
                    {
                        color: colorScheme === 'dark' ? '#fff' : '#2c3e50',
                        fontWeight: isSelected ? 'bold' : '600'
                    }
                ]}>
                    {weather.dayName}
                </Text>
                <Text style={[styles.dayDate, { color: colorScheme === 'dark' ? '#999' : '#7f8c8d' }]}>
                    {weather.date}
                </Text>
            </View>

            <View style={styles.dayCenter}>
                <Text style={styles.dayIcon}>{WEATHER_ICONS[weather.condition]}</Text>
                <View style={styles.dayPrecipitation}>
                    <Text style={styles.dayPrecipitationIcon}>💧</Text>
                    <Text style={[styles.dayPrecipitationText, { color: colorScheme === 'dark' ? '#999' : '#7f8c8d' }]}>
                        {weather.precipitation}%
                    </Text>
                </View>
            </View>

            <View style={styles.dayRight}>
                <Text style={[styles.dayTempMax, { color: colorScheme === 'dark' ? '#fff' : '#2c3e50' }]}>
                    {weather.temperature.max}°
                </Text>
                <Text style={[styles.dayTempMin, { color: colorScheme === 'dark' ? '#999' : '#95a5a6' }]}>
                    {weather.temperature.min}°
                </Text>
            </View>

            {isSelected && (
                <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedDot}>•</Text>
                </View>
            )}
        </TouchableOpacity>
    );
}