import { styles } from '@/styles/weather/weather-card.styles';
import { WeatherDay } from '@/types/weather';
import React from 'react';
import { Text, View } from 'react-native';

interface Props {
    weather: WeatherDay;
}

export default function WeatherDetails({ weather }: Props) {
    return (
        <View style={styles.todayDetails}>
            <View style={styles.todayDetailItem}>
                <Text style={styles.todayDetailIcon}>💧</Text>
                <Text style={styles.todayDetailValue}>{weather.humidity}%</Text>
                <Text style={styles.todayDetailLabel}>Humidity</Text>
            </View>
            <View style={styles.todayDetailItem}>
                <Text style={styles.todayDetailIcon}>💨</Text>
                <Text style={styles.todayDetailValue}>{weather.windSpeed} km/h</Text>
                <Text style={styles.todayDetailLabel}>Wind</Text>
            </View>
            <View style={styles.todayDetailItem}>
                <Text style={styles.todayDetailIcon}>☔</Text>
                <Text style={styles.todayDetailValue}>{weather.precipitation}%</Text>
                <Text style={styles.todayDetailLabel}>Rain</Text>
            </View>
            <View style={styles.todayDetailItem}>
                <Text style={styles.todayDetailIcon}>☀️</Text>
                <Text style={styles.todayDetailValue}>UV {weather.uvIndex}</Text>
                <Text style={styles.todayDetailLabel}>UV Index</Text>
            </View>
        </View>
    );
}