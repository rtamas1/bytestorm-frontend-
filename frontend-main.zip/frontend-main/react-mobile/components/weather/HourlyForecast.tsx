import { styles } from '@/styles/weather/weather-card.styles';
import { HourlyForecast as HourlyForecastType } from '@/types/weather';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';

interface Props {
    forecast: HourlyForecastType[];
}

export default function HourlyForecast({ forecast }: Props) {
    return (
        <View style={styles.hourlyContainer}>
            <Text style={styles.hourlyTitle}>Hourly Forecast</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={styles.hourlyScroll}>
                    {forecast.map((hour, index) => (
                        <View key={index} style={styles.hourlyItem}>
                            <Text style={styles.hourlyTime}>{hour.time}</Text>
                            <Text style={styles.hourlyIcon}>{hour.condition}</Text>
                            <Text style={styles.hourlyTemp}>{hour.temp}°</Text>
                        </View>
                    ))}
                </View>
            </ScrollView>
        </View>
    );
}