import { WEATHER_GRADIENTS, WEATHER_ICONS } from '@/constants/weather';
import { styles } from '@/styles/weather/weather-card.styles';
import { WeatherDay } from '@/types/weather';
import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { Text, View } from 'react-native';
import HourlyForecast from './HourlyForecast';
import SunTimes from './SunTimes';
import WeatherDetails from './WeatherDetails';

interface Props {
    weather: WeatherDay;
}

export default function DetailedWeatherCard({ weather }: Props) {
    const currentTemp = weather.temperature.current || 
        Math.round((weather.temperature.min + weather.temperature.max) / 2);

    return (
        <LinearGradient
            colors={WEATHER_GRADIENTS[weather.condition]}
            style={styles.todayCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
        >
            <View style={styles.todayHeader}>
                <View>
                    <Text style={styles.todayDate}>{weather.dayName}</Text>
                    <Text style={styles.todayDateSub}>{weather.date}</Text>
                </View>
                <Text style={styles.todayIcon}>{WEATHER_ICONS[weather.condition]}</Text>
            </View>

            <View style={styles.todayTempContainer}>
                <Text style={styles.todayTemp}>{currentTemp}°</Text>
                <View style={styles.todayMinMax}>
                    <Text style={styles.todayMinMaxText}>↓ {weather.temperature.min}°</Text>
                    <Text style={styles.todayMinMaxText}>↑ {weather.temperature.max}°</Text>
                </View>
            </View>

            <Text style={styles.todayCondition}>
                {weather.condition.charAt(0).toUpperCase() + 
                 weather.condition.slice(1).replace('-', ' ')}
            </Text>

            <WeatherDetails weather={weather} />
            
            {weather.sunrise && weather.sunset && (
                <SunTimes sunrise={weather.sunrise} sunset={weather.sunset} />
            )}

            {weather.hourlyForecast && weather.hourlyForecast.length > 0 && (
                <HourlyForecast forecast={weather.hourlyForecast} />
            )}
        </LinearGradient>
    );
}