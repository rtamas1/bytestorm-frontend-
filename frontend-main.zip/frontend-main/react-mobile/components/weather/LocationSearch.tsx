import { useColorScheme } from '@/hooks/useColorScheme';
import { searchLocations } from '@/services/weather/api';
import { styles } from '@/styles/weather/location-search.styles';
import { styles as mainStyles } from '@/styles/weather/weather-screen.styles';
import { Location } from '@/types/weather';
import React, { useState } from 'react';
import {
    ActivityIndicator,
    Alert,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';

interface Props {
    currentLocation: Location;
    onLocationSelect: (location: Location) => void;
}

export default function LocationSearch({ currentLocation, onLocationSelect }: Props) {
    const colorScheme = useColorScheme();
    const [showLocationSearch, setShowLocationSearch] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Location[]>([]);
    const [searchingLocation, setSearchingLocation] = useState(false);

    const handleSearch = async () => {
        if (!searchQuery.trim()) return;
        setSearchingLocation(true);
        try {
            const results = await searchLocations(searchQuery);
            setSearchResults(results);
        } catch (error) {
            console.error('Error searching locations:', error);
            Alert.alert('Error', 'Failed to search locations. Please try again.');
        } finally {
            setSearchingLocation(false);
        }
    };

    const selectLocation = (location: Location) => {
        onLocationSelect(location);
        setShowLocationSearch(false);
        setSearchQuery('');
        setSearchResults([]);
    };

    return (
        <>
            {/* Location Header */}
            <View style={mainStyles.header}>
                <TouchableOpacity onPress={() => setShowLocationSearch(!showLocationSearch)}>
                    <View style={mainStyles.locationHeader}>
                        <Text style={[mainStyles.locationTitle, { color: colorScheme === 'dark' ? '#fff' : '#2c3e50' }]}>
                            📍 {currentLocation.name}
                        </Text>
                        <Text style={mainStyles.changeLocation}>Change →</Text>
                    </View>
                    <Text style={[mainStyles.locationSubtitle, { color: colorScheme === 'dark' ? '#999' : '#7f8c8d' }]}>
                        {currentLocation.state ? `${currentLocation.state}, ` : ''}{currentLocation.country}
                    </Text>
                </TouchableOpacity>
            </View>

            {/* Location Search */}
            {showLocationSearch && (
                <View style={[styles.searchContainer, { backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white' }]}>
                    <View style={styles.searchInputContainer}>
                        <TextInput
                            style={[styles.searchInput, { color: colorScheme === 'dark' ? '#fff' : '#000' }]}
                            placeholder="Search for a location..."
                            placeholderTextColor={colorScheme === 'dark' ? '#666' : '#999'}
                            value={searchQuery}
                            onChangeText={setSearchQuery}
                            onSubmitEditing={handleSearch}
                            returnKeyType="search"
                        />
                        <TouchableOpacity onPress={handleSearch} style={styles.searchButton}>
                            {searchingLocation ? (
                                <ActivityIndicator size="small" color="#fff" />
                            ) : (
                                <Text style={styles.searchButtonText}>Search</Text>
                            )}
                        </TouchableOpacity>
                    </View>

                    {searchResults.length > 0 && (
                        <View style={styles.searchResults}>
                            {searchResults.map((location, index) => (
                                <TouchableOpacity
                                    key={index}
                                    style={styles.searchResultItem}
                                    onPress={() => selectLocation(location)}
                                >
                                    <Text style={[styles.searchResultName, { color: colorScheme === 'dark' ? '#fff' : '#000' }]}>
                                        {location.name}
                                    </Text>
                                    <Text style={[styles.searchResultDetails, { color: colorScheme === 'dark' ? '#999' : '#666' }]}>
                                        {location.state ? `${location.state}, ` : ''}{location.country}
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    )}
                </View>
            )}
        </>
    );
}