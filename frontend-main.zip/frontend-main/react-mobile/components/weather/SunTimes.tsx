import { styles } from '@/styles/weather/weather-card.styles';
import React from 'react';
import { Text, View } from 'react-native';

interface Props {
    sunrise: string;
    sunset: string;
}

export default function SunTimes({ sunrise, sunset }: Props) {
    return (
        <View style={styles.sunTimes}>
            <View style={styles.sunTimeItem}>
                <Text style={styles.sunTimeIcon}>🌅</Text>
                <Text style={styles.sunTimeText}>{sunrise}</Text>
            </View>
            <View style={styles.sunTimeItem}>
                <Text style={styles.sunTimeIcon}>🌇</Text>
                <Text style={styles.sunTimeText}>{sunset}</Text>
            </View>
        </View>
    );
}