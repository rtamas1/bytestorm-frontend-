import { useColorScheme } from '@/hooks/useColorScheme';
import { SensorDisplay } from '@/types/greenhouse';
import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

interface Props {
    sensors: SensorDisplay[];
    loading?: boolean;
    error?: string;
}

export default function SensorGrid({ sensors, loading, error }: Props) {
    const colorScheme = useColorScheme();

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="small" color="#007AFF" />
                <Text style={styles.loadingText}>Loading sensors...</Text>
            </View>
        );
    }

    if (error) {
        return (
            <View style={styles.errorContainer}>
                <Text style={styles.errorText}>⚠️ {error}</Text>
            </View>
        );
    }

    // Group sensors into rows (4 per row)
    const rows: SensorDisplay[][] = [];
    for (let i = 0; i < sensors.length; i += 4) {
        rows.push(sensors.slice(i, i + 4));
    }

    return (
        <View style={[
            styles.container,
            { backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white' }
        ]}>
            {rows.map((row, rowIndex) => (
                <View key={rowIndex} style={styles.row}>
                    {row.map((sensor) => (
                        <View
                            key={sensor.id}
                            style={[
                                styles.sensorCard,
                                {
                                    borderTopColor: sensor.color,
                                    backgroundColor: colorScheme === 'dark' ? '#1a1a1a' : 'white',
                                    opacity: sensor.value === 'OFF' ? 0.6 : 1,
                                }
                            ]}
                        >
                            <Text style={styles.sensorIcon}>{sensor.icon}</Text>
                            <Text style={[
                                styles.sensorName,
                                { color: colorScheme === 'dark' ? '#999' : '#7f8c8d' }
                            ]}>
                                {sensor.name}
                            </Text>
                            <Text style={[
                                styles.sensorValue,
                                {
                                    color: sensor.color,
                                    fontWeight: sensor.value === 'ON' || sensor.value === 'OFF' ? '800' : 'bold'
                                }
                            ]}>
                                {sensor.value}
                            </Text>
                            {sensor.status && sensor.status !== 'neutral' && (
                                <View style={[
                                    styles.statusDot,
                                    {
                                        backgroundColor:
                                            sensor.status === 'good' ? '#27ae60' :
                                                sensor.status === 'warning' ? '#f39c12' :
                                                    '#e74c3c'
                                    }
                                ]}
                                />
                            )}
                        </View>
                    ))}
                </View>
            ))}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        paddingHorizontal: 15,
        paddingVertical: 15,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
        borderTopWidth: 1,
        borderTopColor: 'rgba(0,0,0,0.05)',
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },
    sensorCard: {
        borderRadius: 10,
        padding: 10,
        width: '22%',
        alignItems: 'center',
        borderTopWidth: 3,
        position: 'relative',
    },
    sensorIcon: {
        fontSize: 24,
        marginBottom: 6,
    },
    sensorName: {
        fontSize: 9,
        marginBottom: 4,
        textAlign: 'center',
    },
    sensorValue: {
        fontSize: 13,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    statusDot: {
        position: 'absolute',
        top: 5,
        right: 5,
        width: 6,
        height: 6,
        borderRadius: 3,
    },
    loadingContainer: {
        padding: 30,
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 10,
        fontSize: 14,
        color: '#999',
    },
    errorContainer: {
        padding: 20,
        alignItems: 'center',
    },
    errorText: {
        fontSize: 14,
        color: '#e74c3c',
    },
});