import { WeatherCondition } from '@/types/weather';

export const WEATHER_ICONS: Record<WeatherCondition, string> = {
    sunny: '☀️',
    rainy: '🌧️',
    cloudy: '☁️',
    'partly-cloudy': '⛅',
    snowy: '❄️',
    thunderstorm: '⛈️',
    foggy: '🌫️',
};

export const WEATHER_GRADIENTS: Record<WeatherCondition, string[]> = {
    sunny: ['#FFB75E', '#ED8F03'],
    rainy: ['#4CA1AF', '#2C3E50'],
    cloudy: ['#757F9A', '#D7DDE8'],
    'partly-cloudy': ['#89F7FE', '#66A6FF'],
    snowy: ['#E6DADA', '#274046'],
    thunderstorm: ['#373B44', '#4286f4'],
    foggy: ['#8e9eab', '#eef2f3'],
};

export const DEFAULT_LOCATION = {
    name: 'Iași',
    lat: 47.1585,
    lon: 27.6014,
    country: 'RO'
};