import { Location, WeatherDay } from '@/types/weather';
import { processOpenMeteoData } from '../../utils/weather/mappers';

export const searchLocations = async (query: string): Promise<Location[]> => {
    if (!query.trim()) return [];

    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
        query
    )}&count=5&language=en&format=json`;

    const res = await fetch(url);
    const json = await res.json();

    return (json.results || []).map((r: any) => ({
        name: r.name,
        lat: r.latitude,
        lon: r.longitude,
        country: r.country_code || r.country,
        state: r.admin1 || undefined,
    }));
};

export const fetchWeatherData = async (lat: number, lon: number): Promise<WeatherDay[]> => {
    const params = new URLSearchParams({
        latitude: String(lat),
        longitude: String(lon),
        timezone: 'auto',
        wind_speed_unit: 'kmh',
        current: [
            'temperature_2m',
            'relative_humidity_2m',
            'weather_code',
            'wind_speed_10m',
            'uv_index',
        ].join(','),
        hourly: [
            'temperature_2m',
            'relative_humidity_2m',
            'precipitation_probability',
            'weather_code',
            'wind_speed_10m',
            'uv_index',
        ].join(','),
        daily: [
            'temperature_2m_max',
            'temperature_2m_min',
            'weather_code',
            'precipitation_probability_max',
            'uv_index_max',
            'sunrise',
            'sunset',
            'wind_speed_10m_max',
        ].join(','),
        forecast_days: '7',
    });

    const url = `https://api.open-meteo.com/v1/forecast?${params.toString()}`;
    const res = await fetch(url);

    if (!res.ok) throw new Error(`Open-Meteo error ${res.status}`);

    const data = await res.json();
    return processOpenMeteoData(data);
};