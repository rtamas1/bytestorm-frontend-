import { SensorData } from '@/types/greenhouse';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';

const API_BASE_URL = 'http://84.247.140.193:5050/api';
const TOKEN_KEY = '@greenhouse_token';

export type Actuator = 'led' | 'fan' | 'pump' | 'servo';
export type ActuatorValue = 'on' | 'off';

// Helper to get auth headers with stored token
const getAuthHeaders = async () => {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    if (!token || token === 'undefined' || token === 'null') {
        // Clear invalid token and redirect to login
        await AsyncStorage.removeItem(TOKEN_KEY);
        await AsyncStorage.removeItem('@greenhouse_user_role');
        router.replace('/login');
        throw new Error('No valid authentication token found');
    }
    return {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
    };
};

export const fetchSensorData = async (identifier: string): Promise<SensorData> => {
    try {
        const headers = await getAuthHeaders();
        const response = await fetch(`${API_BASE_URL}/sensors?identifier=${identifier}`, { headers });

        if (response.status === 401) {
            // Token expired or invalid
            await AsyncStorage.removeItem(TOKEN_KEY);
            await AsyncStorage.removeItem('@greenhouse_user_role');
            router.replace('/login');
            throw new Error('Session expired. Please login again.');
        }

        if (!response.ok) throw new Error(`API Error: ${response.status}`);
        return response.json();
    } catch (error) {
        console.error('fetchSensorData error:', error);
        throw error;
    }
};

const postWithVariants = async (url: string, variants: any[]) => {
    const headers = await getAuthHeaders();
    let lastErr: Error | null = null;

    for (const body of variants) {
        try {
            const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });

            if (res.status === 401) {
                await AsyncStorage.removeItem(TOKEN_KEY);
                await AsyncStorage.removeItem('@greenhouse_user_role');
                router.replace('/login');
                throw new Error('Session expired. Please login again.');
            }

            const text = await res.text().catch(() => '');
            if (res.ok) {
                try {
                    return text ? JSON.parse(text) : { ok: true };
                } catch {
                    return { ok: true, raw: text };
                }
            }
            lastErr = new Error(`Command error ${res.status}: ${text || res.statusText}`);
        } catch (e: any) {
            lastErr = e;
        }
    }
    throw lastErr ?? new Error('Command failed');
};

export const sendActuatorCommand = async (
    deviceId: string,
    actuator: Actuator,
    value: ActuatorValue
): Promise<any> => {
    const vNum = value === 'on' ? 1 : 0;
    return postWithVariants(`${API_BASE_URL}/command`, [
        { deviceId, actuator, value },
        { identifier: deviceId, actuator, value },
        { deviceId, actuator, value: vNum },
    ]);
};
