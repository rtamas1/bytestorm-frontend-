import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import React, { createContext, useContext, useEffect, useState } from 'react';

const API_BASE_URL = 'http://84.247.140.193:5050/api';
const TOKEN_KEY = '@greenhouse_token';
const USER_ROLE_KEY = '@greenhouse_user_role';

interface AuthContextType {
    token: string | null;
    userRole: number | null;
    isLoading: boolean;
    isAuthenticated: boolean;
    login: (username: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [token, setToken] = useState<string | null>(null);
    const [userRole, setUserRole] = useState<number | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    // Load stored token on app start
    useEffect(() => {
        loadStoredAuth();
    }, []);

    const loadStoredAuth = async () => {
        try {
            const storedToken = await AsyncStorage.getItem(TOKEN_KEY);
            const storedRole = await AsyncStorage.getItem(USER_ROLE_KEY);

            // Only set token if it exists and is valid
            if (storedToken && storedToken !== 'undefined' && storedToken !== 'null') {
                // Optionally validate token format (JWT should have 3 parts)
                const parts = storedToken.split('.');
                if (parts.length === 3) {
                    setToken(storedToken);
                    setUserRole(storedRole ? parseInt(storedRole) : null);
                } else {
                    // Invalid token format, clear it
                    await AsyncStorage.removeItem(TOKEN_KEY);
                    await AsyncStorage.removeItem(USER_ROLE_KEY);
                }
            }
        } catch (error) {
            console.error('Error loading auth:', error);
            // Clear corrupted data
            await AsyncStorage.removeItem(TOKEN_KEY);
            await AsyncStorage.removeItem(USER_ROLE_KEY);
        } finally {
            setIsLoading(false);
        }
    };

    const login = async (username: string, password: string) => {
        try {
            const response = await fetch(`${API_BASE_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText || 'Invalid credentials');
            }

            const data = await response.json();

            // Validate response has required fields
            if (!data.token) {
                throw new Error('Invalid response from server');
            }

            // Store token and role
            await AsyncStorage.setItem(TOKEN_KEY, data.token);
            await AsyncStorage.setItem(USER_ROLE_KEY, data.user_role.toString());

            setToken(data.token);
            setUserRole(data.user_role);

            // Navigate to home after successful login
            router.replace('/(tabs)');
        } catch (error: any) {
            console.error('Login error:', error);
            throw error;
        }
    };

    const logout = async () => {
        try {
            // Clear stored data
            await AsyncStorage.removeItem(TOKEN_KEY);
            await AsyncStorage.removeItem(USER_ROLE_KEY);

            // Clear state
            setToken(null);
            setUserRole(null);

            // Navigate to login
            router.replace('/login');
        } catch (error) {
            console.error('Logout error:', error);
            // Even if there's an error, clear state and navigate
            setToken(null);
            setUserRole(null);
            router.replace('/login');
        }
    };

    return (
        <AuthContext.Provider
            value={{
                token,
                userRole,
                isLoading,
                isAuthenticated: !!token,
                login,
                logout
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};