import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    // Detailed Weather Card Styles
    todayCard: {
        margin: 20,
        marginTop: 10,
        borderRadius: 20,
        padding: 20,
        elevation: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    todayHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
    },
    todayDate: {
        color: 'white',
        fontSize: 24,
        fontWeight: 'bold',
    },
    todayDateSub: {
        color: 'white',
        fontSize: 16,
        opacity: 0.9,
        marginTop: 2,
    },
    todayIcon: {
        fontSize: 60,
    },
    todayTempContainer: {
        flexDirection: 'row',
        alignItems: 'baseline',
        marginTop: 20,
    },
    todayTemp: {
        color: 'white',
        fontSize: 72,
        fontWeight: '300',
    },
    todayMinMax: {
        marginLeft: 15,
    },
    todayMinMaxText: {
        color: 'white',
        fontSize: 18,
        opacity: 0.9,
        marginBottom: 5,
    },
    todayCondition: {
        color: 'white',
        fontSize: 20,
        marginTop: 10,
        opacity: 0.95,
    },
    todayDetails: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 25,
        paddingTop: 20,
        borderTopWidth: 1,
        borderTopColor: 'rgba(255, 255, 255, 0.2)',
    },
    todayDetailItem: {
        alignItems: 'center',
    },
    todayDetailIcon: {
        fontSize: 24,
        marginBottom: 5,
    },
    todayDetailValue: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
    todayDetailLabel: {
        color: 'white',
        fontSize: 12,
        opacity: 0.8,
        marginTop: 2,
    },

    // Sun Times Styles
    sunTimes: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 20,
        paddingTop: 20,
        borderTopWidth: 1,
        borderTopColor: 'rgba(255, 255, 255, 0.2)',
    },
    sunTimeItem: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    sunTimeIcon: {
        fontSize: 20,
        marginRight: 8,
    },
    sunTimeText: {
        color: 'white',
        fontSize: 16,
    },

    // Hourly Forecast Styles
    hourlyContainer: {
        marginTop: 20,
        paddingTop: 20,
        borderTopWidth: 1,
        borderTopColor: 'rgba(255, 255, 255, 0.2)',
    },
    hourlyTitle: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 10,
    },
    hourlyScroll: {
        flexDirection: 'row',
        paddingVertical: 10,
    },
    hourlyItem: {
        alignItems: 'center',
        marginRight: 20,
    },
    hourlyTime: {
        color: 'white',
        fontSize: 12,
        opacity: 0.8,
        marginBottom: 5,
    },
    hourlyIcon: {
        fontSize: 24,
        marginBottom: 5,
    },
    hourlyTemp: {
        color: 'white',
        fontSize: 14,
        fontWeight: 'bold',
    },

    // Day Weather Card Styles
    dayCard: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 15,
        borderRadius: 12,
        marginBottom: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        position: 'relative',
    },
    dayLeft: {
        flex: 1,
    },
    dayName: {
        fontSize: 16,
        fontWeight: '600',
    },
    dayDate: {
        fontSize: 14,
        marginTop: 2,
    },
    dayCenter: {
        alignItems: 'center',
        marginHorizontal: 20,
    },
    dayIcon: {
        fontSize: 32,
    },
    dayPrecipitation: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 5,
    },
    dayPrecipitationIcon: {
        fontSize: 12,
        marginRight: 3,
    },
    dayPrecipitationText: {
        fontSize: 12,
    },
    dayRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    dayTempMax: {
        fontSize: 18,
        fontWeight: 'bold',
        marginRight: 8,
    },
    dayTempMin: {
        fontSize: 18,
    },
    selectedIndicator: {
        position: 'absolute',
        left: 5,
        top: '50%',
        transform: [{ translateY: -10 }],
    },
    selectedDot: {
        color: '#007AFF',
        fontSize: 20,
    },
});