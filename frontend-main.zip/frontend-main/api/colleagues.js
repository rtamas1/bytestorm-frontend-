// În dev: /ext (Vite proxy). În producție: relay server-side /api/relay/colleagues
export const EXT_ROOT = import.meta.env.DEV ? "/ext" : "/api/relay/colleagues";

const USE_MOCK = import.meta.env.DEV && String(import.meta.env.VITE_USE_MOCK || "0") === "1";

const MOCK = {
  SDATA_ID: 51914,
  STIMEACQ: new Date().toISOString(),
  SBOARDID: "e663ac91d3824a2c",
  TEMPAER: 19,
  UMDTAER: 50,
  UMDTSOL1: 96,
  UMDTSOL2: 70,
  NIVELAPA: 73,
  EXCESAPA: 100,
  ILUMINARE: 0,
  CALITAER: 551.41,
  STAREAER: "Clean air",
  TDATA_ID: 51914,
  TTIMEACQ: new Date().toISOString(),
  TBOARDID: "e663ac91d3824a2c",
  UNQHWMAC: "2c:cf:67:9d:4a:ff",
  TBOARDIP: "192.168.0.10",
  SYSUPTIME: 347992739,
  TEMPINT: 22.36,
  FREEMEM: 179472,
  ADATA_ID: 51914,
  ATIMEACQ: new Date().toISOString(),
  ABOARDID: "e663ac91d3824a2c",
  TESTLED: 0,
  TESTFAN: 0,
  TESTSRV: 0,
  TESTPMP: 0,
};

async function fetchJSON(url, init) {
  const res = await fetch(url, { cache: "no-store", ...init });
  const text = await res.text();
  const ctype = res.headers.get("content-type") || "";
  if (!res.ok) {
    if (res.status === 401) throw new Error("Token expirat sau nevalid (401).");
    throw new Error(`HTTP ${res.status}: ${text.slice(0, 200)}`); // <-- backticks, nu string simplu
  }
  if (/application\/json/i.test(ctype)) return JSON.parse(text);
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Nu e JSON: ${text.slice(0, 200)}`); // <-- backticks
  }
}

export function getColleagueSensors(identifier) {
  const url = `${EXT_ROOT}/sensors?identifier=${encodeURIComponent(identifier)}&_=${Date.now()}`; // <-- backticks
  if (USE_MOCK) {
    return fetchJSON(url).catch((err) => {
      console.warn("Folosesc MOCK din cauza erorii:", err?.message || err);
      return MOCK;
    });
  }
  return fetchJSON(url);
}
