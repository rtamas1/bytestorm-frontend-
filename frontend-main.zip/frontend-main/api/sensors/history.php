<?php
// public/api/sensors/history.php
declare(strict_types=1);

/* ==== Config prin ENV ==== */
$COLLEAGUES_BASE   = 'http://84.247.140.193:5050/api';   // <-- ABSOLUT, nu /ext
$COLLEAGUES_BEARER = getenv('COLLEAGUES_BEARER') ?:  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6InRlc3RAZ3JlZW5ob3VzZS5vcmciLCJyb2xlIjoxLCJpYXQiOjE3NTY5NjEyNjEsImV4cCI6MTc1NzA0NzY2MX0.VwLf7TRQC3UfhNc0U23IqS6BZZOtOvaz3zdcViQJzyo'; // opcional
/* ==== Helpers JSON ==== */
header('Content-Type: application/json; charset=utf-8');
function json_ok($data, int $code = 200)
{
    http_response_code($code);
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_SLASHES);
    exit;
}
function json_err($msg, int $code = 400)
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_SLASHES);
    exit;
}

/* ==== Validare input ==== */
$boardId = $_GET['boardId'] ?? '';
$key     = $_GET['key']      ?? '';
$range   = $_GET['range']    ?? '24h';

$allowed = ['TEMPAER', 'UMDTAER', 'UMDTSOL1', 'UMDTSOL2', 'UMDTSOL3', 'UMDTSOL4', 'ILUMINARE', 'NIVELAPA', 'CALITAER'];
if ($boardId === '' || $key === '') json_err('Missing boardId or key', 400);
if (!in_array($key, $allowed, true)) json_err('Cheie senzor invalidă', 400);

/* ==== Interval & utilitare ==== */
function range_bounds(string $range): array
{
    $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
    switch ($range) {
        case '24h':
            $since = $now->modify('-24 hours');
            break;
        case '3d':
            $since = $now->modify('-3 days');
            break;
        case '7d':
            $since = $now->modify('-7 days');
            break;
        case '30d':
            $since = $now->modify('-30 days');
            break;
        case '90d':
        case 'all':
            $since = $now->modify('-90 days');
            break;
        default:
            $since = $now->modify('-24 hours');
            break;
    }
    return [$since, $now];
}
function to_iso_min(DateTimeImmutable $d): string
{
    // YYYY-MM-DDTHH:00:00Z
    return $d->setTime((int)$d->format('H'), 0, 0)->format('Y-m-d\TH:i:s\Z');
}

/* ==== HTTP GET JSON cu timeout ==== */
function get_json(string $url, array $headers = [], int $timeout = 12): array
{
    $ch = curl_init($url);
    $hdrs = array_merge(['Accept: application/json'], $headers);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 5,   // înainte era 6 total; acum 5 conectare
        CURLOPT_TIMEOUT        => $timeout, // 12–15s total
        CURLOPT_HTTPHEADER     => $hdrs,
        CURLOPT_ENCODING       => '',
        CURLOPT_USERAGENT      => 'sensor-history-proxy/1.0',
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($body === false) throw new RuntimeException($err ?: 'curl error');
    if ($code < 200 || $code >= 300) throw new RuntimeException("HTTP $code");
    $j = json_decode($body, true);
    if (!is_array($j)) throw new RuntimeException('invalid json');
    return $j;
}

/* ==== Normalizează -> [{ts,val}] indiferent de formă ==== */
function normalize_points(array $json, string $field): array
{
    // prioritizăm array-ul câmpului
    if (isset($json[$field]) && is_array($json[$field])) $raw = $json[$field];
    elseif (isset($json['rows']) && is_array($json['rows'])) $raw = $json['rows'];
    elseif (isset($json['data']) && is_array($json['data'])) $raw = $json['data'];
    elseif (isset($json['history']) && is_array($json['history'])) $raw = $json['history'];
    elseif (array_is_list($json)) $raw = $json;
    else return [];

    $out = [];
    foreach ($raw as $r) {
        $ts = $r['ts'] ?? $r['timestamp'] ?? $r['time'] ?? $r['date'] ?? null;
        $val = $r['val'] ?? $r['value'] ?? ($r[$field] ?? null);
        if ($ts === null || (!is_numeric($val) && $val !== 0 && $val !== '0')) continue;
        $out[] = ['ts' => $ts, 'val' => is_numeric($val) ? floatval($val) : null];
    }
    return $out;
}

/* ==== Agregare la oră + tăiere la max 300 puncte ==== */
function aggregate_hourly(array $points, string $range): array
{
    if (!$points) return [];
    [$since, $until] = range_bounds($range);
    $start = $since->getTimestamp();
    $end   = $until->getTimestamp();

    // bucket (secunde) în funcție de range
    $bucket = match ($range) {
        '24h' => 3600,
        '3d'  => 3 * 3600,
        '7d'  => 6 * 3600,
        '30d' => 12 * 3600,
        default => 24 * 3600,
    };

    $b = [];
    foreach ($points as $p) {
        $t = is_numeric($p['ts']) ? intval($p['ts']) : strtotime((string)$p['ts']);
        if ($t === false || $t < $start || $t > $end) continue;
        $v = $p['val'];
        if (!is_float($v) && !is_int($v)) continue;
        $k = intdiv($t, $bucket) * $bucket;
        if (!isset($b[$k])) $b[$k] = ['s' => 0.0, 'n' => 0];
        $b[$k]['s'] += $v;
        $b[$k]['n']++;
    }
    ksort($b);
    $out = [];
    foreach ($b as $ts => $agg) {
        $out[] = ['ts' => gmdate('Y-m-d\TH:i:s\Z', $ts), 'val' => $agg['n'] ? $agg['s'] / $agg['n'] : null];
    }
    // reduce la max 300
    $max = 300;
    $len = count($out);
    if ($len > $max) {
        $step = (int)ceil($len / $max);
        $thin = [];
        for ($i = 0; $i < $len; $i += $step) $thin[] = $out[$i];
        if (end($thin) !== end($out)) $thin[] = end($out);
        $out = $thin;
    }
    return $out;
}

/* ==== Cache pe disc (10 min) ==== */
$cacheDir = __DIR__ . '/../_cache';
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0775, true);
$cacheKey = hash('sha256', implode('|', [$boardId, $key, $range]));
$cacheFile = "$cacheDir/$cacheKey.json";
$ttl = 600;

if (is_file($cacheFile) && (time() - filemtime($cacheFile) < $ttl)) {
    $cached = file_get_contents($cacheFile);
    if ($cached !== false) {
        http_response_code(200);
        header('X-Cache: HIT');
        echo $cached;
        exit;
    }
}

/* ==== Fetch: încercăm endpointurile colegilor cu range & field ==== */
try {
    [$since, $until] = range_bounds($range);
    $from = to_iso_min($since);
    $to   = to_iso_min($until);

    $hdrs = $COLLEAGUES_BEARER ? ["Authorization: Bearer {$COLLEAGUES_BEARER}"] : [];

    // 1) preferat: /reports/range?...&field=...&from=...&to=...
    $urls = [
        "{$COLLEAGUES_BASE}/reports/range?identifier=" . rawurlencode($boardId) .
            "&field=" . rawurlencode($key) . "&from=" . rawurlencode($from) . "&to=" . rawurlencode($to),
        // 2) posibil fallback
        "{$COLLEAGUES_BASE}/reports?identifier=" . rawurlencode($boardId) .
            "&field=" . rawurlencode($key) . "&from=" . rawurlencode($from) . "&to=" . rawurlencode($to),
        // 3) minim: doar field
        "{$COLLEAGUES_BASE}/reports?identifier=" . rawurlencode($boardId) .
            "&field=" . rawurlencode($key),
    ];

    $lastErr = null;
    $points = [];

    foreach ($urls as $u) {
        try {
            $j = get_json($u, $hdrs, 6);
            $norm = normalize_points($j, $key);
            if ($norm) {
                // dacă vin deja pe oră, le lăsăm; altfel agregăm
                $points = aggregate_hourly($norm, $range);
                break;
            }
        } catch (Throwable $e) {
            $lastErr = $e;
            continue;
        }
    }

    if (!$points) {
        // ultim fallback (greu): /reports fără field – evită dacă se poate
        $u = "{$COLLEAGUES_BASE}/reports?identifier=" . rawurlencode($boardId);
        $j = get_json($u, $hdrs, 6);
        $norm = normalize_points($j, $key);
        $points = aggregate_hourly($norm, $range);
    }

    $resp = json_encode(['ok' => true, 'data' => $points], JSON_UNESCAPED_SLASHES);
    if ($resp === false) throw new RuntimeException('json encode failed');

    @file_put_contents($cacheFile, $resp);
    header('X-Cache: MISS');
    echo $resp;
    exit;
} catch (Throwable $e) {
    json_err($e->getMessage(), 502);
}
