<?php

declare(strict_types=1);

/* Config (poți lăsa hardcodate dacă vrei 100% zero-config după upload) */
$COLLEAGUES_BASE   = rtrim(getenv('COLLEAGUES_BASE') ?: 'http://84.247.140.193:5050/api', '/');
$COLLEAGUES_BEARER = getenv('COLLEAGUES_BEARER') ?: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyLCJ1c2VybmFtZSI6InRlc3RAZ3JlZW5ob3VzZS5vcmciLCJyb2xlIjoxLCJpYXQiOjE3NTY5NjEyNjEsImV4cCI6MTc1NzA0NzY2MX0.VwLf7TRQC3UfhNc0U23IqS6BZZOtOvaz3zdcViQJzyo';

header('Content-Type: application/json; charset=utf-8');

function bail(int $code, string $msg)
{
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

$uri = $_SERVER['REQUEST_URI'] ?? '/';
$q   = $_SERVER['QUERY_STRING'] ?? '';
$base = '/api/relay/colleagues';
$pos = strpos($uri, $base);
$sub = $pos !== false ? substr($uri, $pos + strlen($base)) : '';
$sub = strtok($sub, '?'); // fără query

// Permit doar /reports și /sensors
$allow = ['/reports', '/sensors'];
if (!in_array($sub, $allow, true)) bail(404, 'Not allowed');

$upstream = $COLLEAGUES_BASE . $sub . ($q ? ('?' . $q) : '');

$ch = curl_init($upstream);
$hdrs = ['Accept: application/json'];
if ($COLLEAGUES_BEARER) $hdrs[] = "Authorization: Bearer {$COLLEAGUES_BEARER}";
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT        => 6,
    CURLOPT_HTTPHEADER     => $hdrs,
    CURLOPT_ENCODING       => '',
    CURLOPT_USERAGENT      => 'colleagues-relay/1.0',
]);

$body = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($body === false) bail(502, $err ?: 'relay error');
http_response_code($code);
echo $body;
